import array
import asyncio
import inspect
import ipaddress
import logging
import struct
import sys
from collections.abc import Callable, Generator, Iterator, MutableSequence, Sequence
from io import IOBase
from typing import Any, Literal, Protocol

from clickhouse_connect.driver.exceptions import DataError, ProgrammingError, StreamClosedError
from clickhouse_connect.driver.types import Closable

logger = logging.getLogger(__name__)


def format_uri_host(host: str) -> str:
    """Bracket a bare IPv6 literal so it can be used in a URI authority.

    RFC 3986 3.2.2 requires the brackets, without them the first colon of the
    address reads as the port separator.  Host names and already bracketed
    hosts are not valid arguments to ip_address, and an IPv4 literal parses but
    is not an IPv6Address, so all three are returned unchanged.  A zone id such
    as fe80::1%lo0 does parse as an IPv6Address and is bracketed.
    """
    try:
        if isinstance(ipaddress.ip_address(host), ipaddress.IPv6Address):
            return f"[{host}]"
    except ValueError:
        pass
    return host


must_swap = sys.byteorder == "big"
int_size = array.array("i").itemsize
low_card_version = 1

array_map = {1: "b", 2: "h", 4: "i", 8: "q"}
decimal_prec = {32: 9, 64: 18, 128: 38, 256: 76}

if int_size == 2:
    array_map[4] = "l"

array_sizes = {v: k for k, v in array_map.items()}
array_sizes["f"] = 4
array_sizes["d"] = 8
np_date_types = {0: "[s]", 3: "[ms]", 6: "[us]", 9: "[ns]"}

ShowClickHouseErrors = bool | Literal["scrub"]


class _CloseableSource(Protocol):
    def close(self) -> object: ...


async def _close_async(source: _CloseableSource) -> None:
    aclose = getattr(source, "aclose", None)
    if aclose is not None:
        await aclose()
        return
    close_result = source.close()
    if inspect.isawaitable(close_result):
        await close_result


def array_type(size: int, signed: bool):
    """
    Determines the Python array.array code for the requested byte size
    :param size: byte size
    :param signed: whether int types should be signed or unsigned
    :return: Python array.array code
    """
    try:
        code = array_map[size]
    except KeyError:
        return None
    return code if signed else code.upper()


def write_array(code: str, column: Sequence, dest: MutableSequence, col_name: str | None = None):
    """
    Write a column of native Python data matching the array.array code
    :param code: Python array.array code matching the column data type
    :param column: Column of native Python values
    :param dest: Destination byte buffer
    :param col_name: Optional column name for error tracking
    """
    try:
        buff = struct.Struct(f"<{len(column)}{code}")
        dest += buff.pack(*column)
    except (TypeError, OverflowError, struct.error) as ex:
        raise _native_array_error(ex, col_name) from ex


def _native_array_error(ex: TypeError | OverflowError | struct.error, col_name: str | None) -> DataError:
    col_msg = f" for column `{col_name}`" if col_name else ""
    error_detail = str(ex)
    if isinstance(ex, OverflowError) or (
        isinstance(ex, struct.error)
        and (error_detail == "argument out of range" or ("format requires " in error_detail and " <= number <= " in error_detail))
    ):
        error_detail = "value out of range"
    elif isinstance(ex, TypeError) or error_detail == "required argument is not an integer":
        error_detail = "type mismatch (usually None in non-Nullable column)"
    return DataError(f"Unable to create native array{col_msg}: {error_detail}")


def write_uint64(value: int, dest: MutableSequence):
    """
    Write a single UInt64 value to a binary write buffer
    :param value: UInt64 value to write
    :param dest: Destination byte buffer
    """
    dest.extend(value.to_bytes(8, "little"))


def write_leb128(value: int, dest: MutableSequence):
    """
    Write a LEB128 encoded integer to a target binary buffer
    :param value: Integer value (positive only)
    :param dest: Target buffer
    """
    while True:
        b = value & 0x7F
        value >>= 7
        if value == 0:
            dest.append(b)
            return
        dest.append(0x80 | b)


def decimal_size(prec: int):
    """
    Determine the bit size of a ClickHouse or Python Decimal needed to store a value of the requested precision
    :param prec: Precision of the Decimal in total number of base 10 digits
    :return: Required bit size
    """
    if prec < 1 or prec > 79:
        raise ArithmeticError(f"Invalid precision {prec} for ClickHouse Decimal type")
    if prec < 10:
        return 32
    if prec < 19:
        return 64
    if prec < 39:
        return 128
    return 256


def unescape_identifier(x: str) -> str:
    """
    Remove backtick or double-quote quoting from a ClickHouse identifier, including compound
    identifiers such as `directory`.`id` (the wire form of a Nested sub-column),
    which normalizes to directory.id. Dots outside of backticks are treated as
    separators between identifier parts, while dots inside backticks are kept.

    Inside a quoted part the escapes produced by quote_identifier are reversed:
    a doubled quote and a backslash-escaped character each yield the single
    literal character they encode, so both `a``b` and `a\\`b` normalize to a`b.
    """
    parts = []
    buf = ""
    quote: str | None = None
    i = 0
    length = len(x)
    while i < length:
        ch = x[i]
        if quote:
            if ch == quote:
                if i + 1 < length and x[i + 1] == quote:
                    buf += quote
                    i += 2
                    continue
                quote = None
            elif ch == "\\" and i + 1 < length:
                # A backslash escapes the next character (for example \` or \\).
                buf += x[i + 1]
                i += 2
                continue
            else:
                buf += ch
        elif ch in ("`", '"'):
            quote = ch
        elif ch == ".":
            parts.append(buf)
            buf = ""
        else:
            buf += ch
        i += 1
    parts.append(buf)
    return ".".join(parts)


def dict_copy(source: dict | None = None, update: dict | None = None) -> dict:
    copy = source.copy() if source else {}
    if update:
        copy.update(update)
    return copy


def dict_add(source: dict, key: str, value: Any) -> dict:
    if value is not None:
        source[key] = value
    return source


def empty_gen():
    yield from ()


def coerce_int(val: str | int | None) -> int:
    if not val:
        return 0
    return int(val)


def coerce_bool(val: str | bool | None) -> bool:
    if not val:
        return False
    return val is True or (isinstance(val, str) and val.lower() in ("true", "1", "y", "yes"))


def coerce_show_clickhouse_errors(val: ShowClickHouseErrors | str | None) -> ShowClickHouseErrors:
    """
    Normalize show_clickhouse_errors to True, False, or the string "scrub".

    "scrub" keeps the SQL error text and symbolic name but strips the server
    URL and the trailing "(version ...)" trailer from exception messages.
    Boolean strings keep their historical behavior. Unknown strings are rejected.
    """
    if val is None:
        return False
    if isinstance(val, bool):
        return val
    if isinstance(val, str):
        normalized = val.strip().lower()
        if normalized == "scrub":
            return "scrub"
        if normalized in ("true", "1", "y", "yes"):
            return True
        if normalized in ("false", "0", "n", "no", ""):
            return False
        raise ProgrammingError(f'show_clickhouse_errors must be true, false, or "scrub", got "{val}"')
    raise ProgrammingError(f'show_clickhouse_errors must be true, false, or "scrub", got {val!r}')


def version_at_least(server_version: str | None, required_version: str) -> bool:
    """
    Determine whether server_version is at least required_version.
    Non-numeric version parts are ignored so Altinity Stable versions
    like 22.8.15.25.altinitystable compare correctly.
    """
    try:
        server_parts = [int(x) for x in (server_version or "").split(".") if x.isnumeric()]
        server_parts.extend([0] * (4 - len(server_parts)))
        required_parts = [int(x) for x in required_version.split(".")]
        required_parts.extend([0] * (4 - len(required_parts)))
    except ValueError:
        logger.warning(
            "Server %s or requested version %s does not match format of numbers separated by dots", server_version, required_version
        )
        return False
    for server_part, required_part in zip(server_parts, required_parts):
        if server_part > required_part:
            return True
        if server_part < required_part:
            return False
    return True


def first_value(column: Sequence, nullable: bool = True):
    if nullable:
        return next((x for x in column if x is not None), None)
    if len(column):
        return column[0]
    return None


class SliceView(Sequence):
    """
    Provides a view into a sequence rather than copying.  Borrows liberally from
    https://gist.github.com/mathieucaroff/0cf094325fb5294fb54c6a577f05a2c1
    Also see the discussion on SO: https://stackoverflow.com/questions/3485475/can-i-create-a-view-on-a-python-list
    """

    slots = ("_source", "_range")

    _source: Sequence
    _range: range

    def __init__(self, source: Sequence, source_slice: slice | None = None):
        if isinstance(source, SliceView):
            self._source = source._source
            self._range = source._range if source_slice is None else source._range[source_slice]
        else:
            self._source = source
            if source_slice is None:
                self._range = range(len(source))
            else:
                self._range = range(len(source))[source_slice]

    def __len__(self):
        return len(self._range)

    def __getitem__(self, i):
        if isinstance(i, slice):
            return SliceView(self._source, i)
        return self._source[self._range[i]]

    def __str__(self):
        r = self._range
        return str(self._source[slice(r.start, r.stop, r.step)])

    def __repr__(self):
        r = self._range
        return f"SliceView({self._source[slice(r.start, r.stop, r.step)]})"

    def __eq__(self, other):
        if self is other:
            return True
        if len(self) != len(other):
            return False
        for v, w in zip(self, other):
            if v != w:
                return False
        return True


_END_OF_BLOCK = object()


def _next_wrapper(gen: Iterator) -> tuple[bool, Any]:
    try:
        return True, next(gen)
    except StopIteration:
        return False, None


class _RowStreamState:
    __slots__ = "row_blocks", "rows"

    def __init__(self, row_blocks: Generator):
        self.row_blocks: Generator | None = row_blocks
        self.rows: Iterator = iter(())


def _iterate_rows(state: _RowStreamState) -> Generator:
    while state.row_blocks is not None:
        rows = state.rows
        yield from rows
        # Async iteration may have moved to another block while this generator was paused.
        if rows is state.rows:
            try:
                state.rows = iter(next(state.row_blocks))
            except StopIteration:
                return


class StreamContext:
    """
    Wraps a generator and its "source" in a Context.  This ensures that the source will be "closed" even if the
    generator is not fully consumed or there is an exception during consumption. Supports both synchronous and
    asynchronous usage.
    """

    __slots__ = "source", "gen", "_in_context", "_row_stream", "_block_lock"

    def __init__(self, source: Closable | IOBase, gen: Generator, *, row_stream: bool = False):
        self.source = source
        self._in_context = False
        # Both protocols consume the same rows; async fetches whole blocks in the executor.
        self._row_stream = _RowStreamState(gen) if row_stream else None
        self._block_lock: asyncio.Lock | None = None
        self.gen: Generator | None = _iterate_rows(self._row_stream) if self._row_stream is not None else gen

    def _reset(self) -> None:
        self.gen = None
        if self._row_stream is not None:
            self._row_stream.row_blocks = None
            self._row_stream.rows = iter(())
            self._row_stream = None

    def __iter__(self):
        return self

    def __next__(self):
        if not self._in_context:
            raise ProgrammingError("Stream should be used within a context")
        return next(self.gen)

    def __enter__(self):
        if not self.gen:
            raise StreamClosedError
        self._in_context = True
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self._in_context = False
        try:
            self.source.close()
        finally:
            self._reset()

    def __aiter__(self):
        return self

    async def __anext__(self):
        if not self._in_context:
            raise ProgrammingError("Stream should be used within a context")
        try:
            if hasattr(self.gen, "__anext__"):
                return await self.gen.__anext__()

            row_stream = self._row_stream
            if row_stream is None:
                loop = asyncio.get_running_loop()
                has_value, value = await loop.run_in_executor(None, _next_wrapper, self.gen)
                if not has_value:
                    raise StopAsyncIteration from None
                return value
            row = next(row_stream.rows, _END_OF_BLOCK)
            if row is not _END_OF_BLOCK:
                return row
            if self._block_lock is None:
                self._block_lock = asyncio.Lock()
            async with self._block_lock:
                row = next(row_stream.rows, _END_OF_BLOCK)
                while row is _END_OF_BLOCK:
                    loop = asyncio.get_running_loop()
                    has_block, block = await loop.run_in_executor(None, _next_wrapper, row_stream.row_blocks)
                    if not has_block:
                        raise StopAsyncIteration from None
                    row_stream.rows = iter(block)
                    row = next(row_stream.rows, _END_OF_BLOCK)
                return row
        except (StopAsyncIteration, StopIteration):
            raise StopAsyncIteration from None
        except Exception as ex:
            if not isinstance(ex, StreamClosedError):
                self._in_context = False
                try:
                    await _close_async(self.source)
                finally:
                    self._reset()
            raise ex

    async def __aenter__(self):
        if not self.gen:
            raise StreamClosedError
        self._in_context = True
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        self._in_context = False
        try:
            await _close_async(self.source)
        finally:
            self._reset()


def get_rename_method(method: str | None) -> Callable[[str], str] | None:
    def _to_camel(s: str) -> str:
        if not s:
            return ""
        out, up = [], False
        for ch in s:
            if ch.isspace() or ch == "_":
                up = True
            elif up:
                out.append(ch.upper())
                up = False
            else:
                out.append(ch)
        return "".join(out)

    def _to_underscore(s: str) -> str:
        if not s:
            return ""
        out, prev = [], 0
        for ch in s:
            if ch.isspace():
                if prev == 0:
                    out.append("_")
                prev = 1
            elif ch.isupper():
                if prev == 0:
                    out.append("_")
                    out.append(ch.lower())
                elif prev == 1:
                    out.append(ch.lower())
                else:
                    out.append(ch)
                prev = 2
            else:
                out.append(ch)
                prev = 0
        return "".join(out)[1:] if out and out[0] == "_" else "".join(out)

    def _remove_prefix(s: str) -> str:
        i = s.rfind(".")
        return s[i + 1 :] if i >= 0 else s

    if not method:
        return None

    name = method.strip().upper()

    if name == "NONE":
        return None
    if name == "REMOVE_PREFIX":
        return _remove_prefix
    if name == "TO_CAMELCASE":
        return _to_camel
    if name == "TO_CAMELCASE_WITHOUT_PREFIX":
        return lambda s: _to_camel(_remove_prefix(s))
    if name == "TO_UNDERSCORE":
        return _to_underscore
    if name == "TO_UNDERSCORE_WITHOUT_PREFIX":
        return lambda s: _to_underscore(_remove_prefix(s))

    valid_options = [
        "none",
        "remove_prefix",
        "to_camelcase",
        "to_camelcase_without_prefix",
        "to_underscore",
        "to_underscore_without_prefix",
    ]
    raise ValueError(f"Invalid option '{name}'. Expected one of {valid_options}")
