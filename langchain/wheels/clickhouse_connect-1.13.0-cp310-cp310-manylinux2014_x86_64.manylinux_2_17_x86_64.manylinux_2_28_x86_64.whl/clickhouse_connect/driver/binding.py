import copy
import ipaddress
import re
import uuid
import zoneinfo
from collections.abc import Collection, Iterator, Mapping, Sequence
from datetime import date, datetime, time, timedelta, timezone, tzinfo
from enum import Enum
from functools import lru_cache
from typing import Any
from urllib.parse import quote, urlencode

from clickhouse_connect import common
from clickhouse_connect.driver import tzutil
from clickhouse_connect.driver.common import dict_copy
from clickhouse_connect.driver.exceptions import ProgrammingError
from clickhouse_connect.driver.parser import parse_callable, parse_columns
from clickhouse_connect.json_impl import any_to_json

BS = "\\"
must_escape = (BS, "'", "`", "\t", "\n")
_STR_ESCAPES = str.maketrans({c: BS + c for c in must_escape})
_BYTE_ESCAPES = tuple(f"{BS}x{b:02x}" for b in range(256))
# ClickHouse substitution names are ASCII BareWord tokens. Digit-led tokens promote to
# a bareword only through ASCII letters, digits, and underscores and never absorb `$`.
_BIND_NAME_PATTERN = r"(?:[A-Za-z_][A-Za-z0-9_$]*|\$[A-Za-z0-9_][A-Za-z0-9_$]*|[0-9]+[A-Za-z_][A-Za-z0-9_]*)"
_bind_name_re = re.compile(rf"{_BIND_NAME_PATTERN}\Z")
# Routing keeps the shipped 1.x `\w+` names such as `{13:Int32}` or `{idé:Int32}`
# in the union for unquoted placeholders. `\w` cannot absorb `$`.
external_bind_re = re.compile(rf"\{{({_BIND_NAME_PATTERN}|\w+):([^}}]+)\}}")
_heredoc_re = re.compile(r"\$[A-Za-z0-9_]*\$")
_heredoc_start_re = re.compile(r"(?=(\$[A-Za-z0-9_]*\$))")
_quote_closers = {"'": "'", '"': '"', "`": "`"}
_curly_quote_closers = {"\u2018": "\u2019", "\u201c": "\u201d"}
_SQL_WHITESPACE = (
    " \t\n\r\v\f"
    "\u0085\u00a0\u180e"
    "\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u200b\u200c\u200d"
    "\u2028\u2029\u202f\u205f\u2060\u3000\ufeff"
)


def _skip_quoted_token(query: str, index: int, quote: str) -> int:
    index += 1
    end = len(query)
    closer = query.find(quote, index)
    while closer != -1:
        backslash = query.find("\\", index, closer)
        if backslash != -1:
            index = backslash + 2
            if index > closer:
                closer = query.find(quote, index)
            continue
        if closer + 1 < end and query[closer + 1] == quote:
            index = closer + 2
            closer = query.find(quote, index)
            continue
        return closer + 1
    return -1


def _skip_block_comment(query: str, index: int) -> int:
    depth = 1
    index += 2
    close = query.find("*/", index)
    while close != -1:
        opener = query.find("/*", index, close + 1)
        if opener != -1:
            depth += 1
            index = opener + 2
            if index > close:
                close = query.find("*/", index)
        else:
            depth -= 1
            index = close + 2
            if depth == 0:
                return index
            close = query.find("*/", index)
    return -1


_SQL_TOKEN_INVALID = 0
_SQL_TOKEN_TRIVIA = 1
_SQL_TOKEN_WORD = 2
_SQL_TOKEN_SEMICOLON = 3
_SQL_TOKEN_OPEN_PAREN = 4
_SQL_TOKEN_CLOSE_PAREN = 5
_SQL_TOKEN_OTHER = 6


def _skip_ascii_bareword(query: str, index: int) -> int:
    end = len(query)
    first = query[index]
    index += 1
    if "0" <= first <= "9":
        while index < end and "0" <= query[index] <= "9":
            index += 1
        if index >= end or not (query[index] == "_" or "A" <= query[index] <= "Z" or "a" <= query[index] <= "z"):
            return index
        index += 1
        while index < end and _is_ascii_word_char(query[index]):
            index += 1
        return index

    while index < end and _is_ascii_bareword_char(query[index]):
        index += 1
    return index


# clickhouse_connect/driverc/sqlscan.pyx mirrors this lexer, _sql_opaque_regions, and remove_sql_comments,
# _matches_outside_quotes and _SQL_COMMENT_MARKERS in query.py. Keep them in sync.
def _next_sql_token(query: str, index: int, heredoc_ends: dict[str, int]) -> tuple[int, int]:
    """Return the next SQL token kind and its exclusive end offset."""
    end = len(query)
    char = query[index]
    if char in _SQL_WHITESPACE:
        index += 1
        while index < end and query[index] in _SQL_WHITESPACE:
            index += 1
        return _SQL_TOKEN_TRIVIA, index

    curly_close = _curly_quote_closers.get(char)
    if curly_close is not None:
        close = query.find(curly_close, index + 1)
        return (_SQL_TOKEN_INVALID, end) if close == -1 else (_SQL_TOKEN_OTHER, close + 1)

    quote_close = _quote_closers.get(char)
    if quote_close is not None:
        close = _skip_quoted_token(query, index, quote_close)
        return (_SQL_TOKEN_INVALID, end) if close == -1 else (_SQL_TOKEN_OTHER, close)

    if query.startswith("/*", index):
        close = _skip_block_comment(query, index)
        return (_SQL_TOKEN_INVALID, end) if close == -1 else (_SQL_TOKEN_TRIVIA, close)

    if (
        query.startswith("--", index)
        or query.startswith("//", index)
        or (char == "#" and index + 1 < end and query[index + 1] in (" ", "!"))
    ):
        newline = query.find("\n", index + 1)
        return _SQL_TOKEN_TRIVIA, end if newline == -1 else newline + 1

    if char == "{":
        placeholder = external_bind_re.match(query, index)
        if placeholder is not None:
            return _SQL_TOKEN_OTHER, placeholder.end()

    if char == ";":
        return _SQL_TOKEN_SEMICOLON, index + 1
    if char == "(":
        return _SQL_TOKEN_OPEN_PAREN, index + 1
    if char == ")":
        return _SQL_TOKEN_CLOSE_PAREN, index + 1

    if char == "$":
        opener = _heredoc_re.match(query, index)
        if opener is not None:
            tag = opener.group()
            if heredoc_ends.get(tag, -1) >= opener.end():
                close = query.find(tag, opener.end())
                return _SQL_TOKEN_OTHER, close + len(tag)
        index += 1
        if index < end and _is_ascii_word_char(query[index]):
            index += 1
            while index < end and _is_ascii_bareword_char(query[index]):
                index += 1
        return _SQL_TOKEN_OTHER, index

    if char == "_" or "A" <= char <= "Z" or "a" <= char <= "z":
        return _SQL_TOKEN_WORD, _skip_ascii_bareword(query, index)
    if "0" <= char <= "9":
        return _SQL_TOKEN_OTHER, _skip_ascii_bareword(query, index)
    return _SQL_TOKEN_OTHER, index + 1


# Characters that start a token which hides other SQL text: quoted strings and identifiers, {name:Type}
# placeholders and the comment forms of the server lexer. Only "$" can also continue a bareword.
_sql_opaque_start_re = re.compile(r"""['"`\u2018\u201c{$]|--|//|/\*|#[ !]""")
# The same starts. A quoted string without escapes is matched whole, because it ends at its first closing quote.
_sql_opaque_token_re = re.compile(r"""'[^'\\]*'(?!')|"[^"\\]*"(?!")|`[^`\\]*`(?!`)|""" + _sql_opaque_start_re.pattern)


def _sql_opaque_regions(query: str) -> Iterator[tuple[int, int]]:
    """Yield the (start, end) of each comment, quoted string, quoted identifier and heredoc, in order.

    Stops at the first unterminated token. Jumps between possible starts, reading a "$" from its
    enclosing ASCII word boundary because it can continue a bareword or open a heredoc.
    """
    heredoc_ends: dict[str, int] = {}
    heredocs_scanned = False
    index = 0
    end = len(query)
    while index < end:
        match = _sql_opaque_token_re.search(query, index)
        if match is None:
            return
        start = match.start()
        if match.end() - start > 1 and query[start] in _quote_closers:
            yield start, match.end()
            index = match.end()
            continue
        token_limit = match.end()
        if query[start] == "$":
            if not heredocs_scanned:
                heredoc_ends = {match.group(1): match.start() for match in _heredoc_start_re.finditer(query)}
                heredocs_scanned = True
            while start > index and _is_ascii_bareword_char(query[start - 1]):
                start -= 1
        index = start
        while index < token_limit:
            token, token_end = _next_sql_token(query, index, heredoc_ends)
            if token == _SQL_TOKEN_INVALID:
                return
            char = query[index]
            if token == _SQL_TOKEN_TRIVIA:
                is_opaque = char not in _SQL_WHITESPACE
            elif token == _SQL_TOKEN_OTHER:
                opener = _heredoc_re.match(query, index) if char == "$" else None
                is_opaque = (
                    char in _quote_closers
                    or char in _curly_quote_closers
                    or (opener is not None and heredoc_ends.get(opener.group(), -1) >= opener.end())
                )
            else:
                is_opaque = False
            if is_opaque:
                yield index, token_end
            index = token_end


def _query_has_trailing_limit_zero(query: str) -> bool:
    """Return whether the query ends in a real lexical LIMIT 0."""
    heredoc_ends = {match.group(1): match.start() for match in _heredoc_start_re.finditer(query)} if "$" in query else {}

    previous = None
    current = None
    candidate_before_semicolon = False
    after_semicolon = False
    index = 0
    end = len(query)

    def suffix_is_limit_zero() -> bool:
        if previous is None or current is None:
            return False

        previous_token, previous_start, previous_end = previous
        current_token, current_start, current_end = current

        return (
            previous_token == _SQL_TOKEN_WORD
            and query[previous_start:previous_end].upper() == "LIMIT"
            and current_token == _SQL_TOKEN_OTHER
            and query[current_start:current_end] == "0"
        )

    while index < end:
        token, token_end = _next_sql_token(query, index, heredoc_ends)

        if token == _SQL_TOKEN_INVALID:
            return False

        if token == _SQL_TOKEN_TRIVIA:
            index = token_end
            continue

        if token == _SQL_TOKEN_SEMICOLON:
            if not after_semicolon:
                candidate_before_semicolon = suffix_is_limit_zero()
            after_semicolon = True
            index = token_end
            continue

        if after_semicolon:
            previous = None
            current = None
            candidate_before_semicolon = False
            after_semicolon = False

        previous, current = current, (token, index, token_end)
        index = token_end

    return candidate_before_semicolon if after_semicolon else suffix_is_limit_zero()


def _strip_trailing_semicolons(query: str) -> str:
    """Remove query-final statement terminators while preserving trailing SQL trivia.

    Only for queries that get a FORMAT clause appended. Must not see inline INSERT
    data, which the server never lexes. Token rules mirror _external_bind_matches.
    """
    if ";" not in query:
        return query

    # _heredoc_start_re finds all overlapping starts, so every _heredoc_re match key exists.
    heredoc_ends = {match.group(1): match.start() for match in _heredoc_start_re.finditer(query)} if "$" in query else {}
    terminators: list[int] = []
    index = 0
    end = len(query)
    while index < end:
        token, token_end = _next_sql_token(query, index, heredoc_ends)
        if token == _SQL_TOKEN_INVALID:
            return query
        if token == _SQL_TOKEN_TRIVIA:
            index = token_end
            continue
        if token == _SQL_TOKEN_SEMICOLON:
            terminators.append(index)
            index = token_end
            continue

        terminators.clear()
        index = token_end

    if not terminators:
        return query
    parts = []
    start = 0
    for position in terminators:
        parts.append(query[start:position])
        start = position + 1
    parts.append(query[start:])
    return "".join(parts)


def _needs_trailing_semicolon_lexer(query: str) -> bool:
    """Return whether query-final terminators need the SQL lexer."""
    if ";" not in query:
        return False
    if not query.endswith(";"):
        return True
    final_run = len(query) - 1
    while final_run > 0 and query[final_run - 1] == ";":
        final_run -= 1
    return query.rfind(";", 0, final_run) != -1


def _is_valid_bind_name(name: str) -> bool:
    return _bind_name_re.fullmatch(name) is not None


def _is_binary_bind_name(name: str) -> bool:
    return len(name) > 1 and name.startswith("$") and name.endswith("$")


def _is_ascii_word_char(char: str) -> bool:
    return char == "_" or "0" <= char <= "9" or "A" <= char <= "Z" or "a" <= char <= "z"


def _is_ascii_bareword_char(char: str) -> bool:
    return char == "$" or _is_ascii_word_char(char)


def _next_keyword_is_into(query: str, index: int, heredoc_ends: dict[str, int]) -> bool:
    end = len(query)
    while index < end:
        token, token_end = _next_sql_token(query, index, heredoc_ends)
        if token == _SQL_TOKEN_TRIVIA:
            index = token_end
            continue
        return token == _SQL_TOKEN_WORD and query[index:token_end].upper() == "INTO"
    return False


_INSERT_BOUNDARY_CHARS = frozenset("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_$")


def _contains_insert_bareword(query: str) -> bool:
    upper_query = query.upper()
    index = upper_query.find("INSERT")
    while index != -1:
        keyword_end = index + 6
        before_is_word = index > 0 and upper_query[index - 1] in _INSERT_BOUNDARY_CHARS
        after_is_word = keyword_end < len(upper_query) and upper_query[keyword_end] in _INSERT_BOUNDARY_CHARS
        if not before_is_word and not after_is_word:
            return True
        index = upper_query.find("INSERT", keyword_end)
    return False


def _query_is_insert(query: str) -> bool:
    """Return whether the leading statement is INSERT, including WITH prefixes.

    Keywords are not reserved, so a bareword INSERT counts only when followed
    by INTO, a pair identifiers can never legally form.
    """
    index = 0
    end = len(query)

    # Ordinary statements return after their first token. WITH needs the deeper scan below.
    while index < end:
        token, token_end = _next_sql_token(query, index, {})
        if token == _SQL_TOKEN_TRIVIA:
            index = token_end
            continue
        if token != _SQL_TOKEN_WORD:
            return False
        keyword = query[index:token_end].upper()
        if keyword == "INSERT":
            return _next_keyword_is_into(query, token_end, {})
        if keyword != "WITH":
            return False
        index = token_end
        break
    else:
        return False

    if not _contains_insert_bareword(query):
        return False
    heredoc_ends = (
        {match.group(1): match.start() for match in _heredoc_start_re.finditer(query, index)} if query.find("$", index) != -1 else {}
    )
    depth = 0
    while index < end:
        token, token_end = _next_sql_token(query, index, heredoc_ends)
        if token == _SQL_TOKEN_INVALID:
            return False
        if token == _SQL_TOKEN_OPEN_PAREN:
            depth += 1
            index = token_end
            continue
        if token == _SQL_TOKEN_CLOSE_PAREN:
            depth = max(0, depth - 1)
            index = token_end
            continue
        if (
            token == _SQL_TOKEN_WORD
            and not depth
            and query[index:token_end].upper() == "INSERT"
            and _next_keyword_is_into(query, token_end, heredoc_ends)
        ):
            return True
        index = token_end
    return False


def _query_is_read_only(query: str | bytes) -> bool:
    """Recognize read statements eligible for HTTP retries. Unknown SQL fails closed."""
    if isinstance(query, bytes):
        query = query.decode("utf-8", errors="surrogateescape")
    # Reject non-read prefixes before scanning inline insert data for heredocs.
    index = 0
    while index < len(query):
        token, token_end = _next_sql_token(query, index, {})
        if token == _SQL_TOKEN_TRIVIA:
            index = token_end
            continue
        if token != _SQL_TOKEN_OPEN_PAREN and (
            token != _SQL_TOKEN_WORD
            or query[index:token_end].upper() not in ("SELECT", "SHOW", "DESCRIBE", "DESC", "EXISTS", "WITH", "EXPLAIN")
        ):
            return False
        break
    else:
        return False

    heredoc_ends = {match.group(1): match.start() for match in _heredoc_start_re.finditer(query)} if "$" in query else {}
    state = "start"
    depth = 0
    statement_depth = 0
    previous_word = ""
    terminated = False
    while index < len(query):
        token, token_end = _next_sql_token(query, index, heredoc_ends)
        value = query[index:token_end]
        index = token_end
        if token == _SQL_TOKEN_TRIVIA:
            continue
        if token == _SQL_TOKEN_INVALID:
            return False
        if token == _SQL_TOKEN_SEMICOLON:
            if depth:
                return False
            terminated = True
            continue
        if terminated:
            return False
        word = value.upper() if token == _SQL_TOKEN_WORD else ""
        if (
            (previous_word == "PARALLEL" and word == "WITH")
            or (previous_word == "INTO" and word == "OUTFILE")
            or (previous_word == "INSERT" and word == "INTO")
        ):
            return False
        previous_word = word

        if token == _SQL_TOKEN_OPEN_PAREN:
            depth += 1
            if state in ("start", "explain", "explain_query", "explain_end"):
                statement_depth = depth
            elif state == "with_value" and depth == statement_depth + 1:
                state = "with_subquery"
            continue
        if token == _SQL_TOKEN_CLOSE_PAREN:
            depth -= 1
            if depth < 0:
                return False
            if state == "with_subquery" and depth == statement_depth:
                state = "with_end"
            continue
        if depth != statement_depth:
            continue

        if state == "start":
            if word in ("SELECT", "SHOW", "DESCRIBE", "DESC", "EXISTS"):
                state = "read"
            elif word == "WITH":
                state = "with_expression"
            elif word == "EXPLAIN":
                state = "explain"
            else:
                return False
        elif state == "explain":
            if word in ("AST", "SYNTAX", "PLAN", "PIPELINE", "ESTIMATE"):
                state = "explain_query"
            elif word == "QUERY":
                state = "explain_tree"
            elif word == "SELECT":
                state = "read"
            elif word == "WITH":
                state = "with_expression"
            else:
                if not word:
                    return False
                state = "explain_equals"
        elif state == "explain_tree":
            if word != "TREE":
                return False
            state = "explain_query"
        elif state == "explain_query":
            if word == "SELECT":
                state = "read"
            elif word == "WITH":
                state = "with_expression"
            else:
                if not word:
                    return False
                state = "explain_equals"
        elif state == "explain_equals":
            if value != "=":
                return False
            state = "explain_value"
        elif state == "explain_value":
            if value not in ("+", "-"):
                state = "explain_end"
        elif state == "explain_end":
            if word == "SELECT":
                state = "read"
            elif word == "WITH":
                state = "with_expression"
            elif value == ",":
                state = "explain_query"
            else:
                return False
        elif state == "with_expression":
            if word == "AS":
                state = "with_value"
        elif state == "with_value":
            state = "with_end"
        elif state == "with_end":
            if word == "SELECT":
                state = "read"
            elif value == ",":
                state = "with_expression"
            else:
                return False
        if state == "read":
            # A read can only introduce another operation through these suffixes.
            upper_query = query.upper()
            if ";" not in upper_query and "PARALLEL" not in upper_query and "INTO" not in upper_query:
                return True
            state = "read_suffix"
    return state == "read_suffix" and depth == 0


def _external_bind_matches(query: str, marker_keys: set[str]) -> tuple[list[re.Match[str]], dict[str, set[int]]]:
    matches = []
    raw_markers: dict[str, set[int]] = {}
    last_heredoc_starts = {match.group(1): match.start() for match in _heredoc_start_re.finditer(query)}
    index = 0
    end = len(query)
    while index < end:
        char = query[index]
        curly_close = _curly_quote_closers.get(char)
        if curly_close is not None:
            close = query.find(curly_close, index + 1)
            index = end if close == -1 else close + 1
            continue

        quote_close = _quote_closers.get(char)
        if quote_close is not None:
            index += 1
            while index < end:
                if query[index] == "\\" and index + 1 < end:
                    index += 2
                elif query[index] == quote_close:
                    if index + 1 < end and query[index + 1] == quote_close:
                        index += 2
                    else:
                        index += 1
                        break
                else:
                    index += 1
            continue

        if query.startswith("/*", index):
            depth = 1
            index += 2
            while index < end and depth:
                if query.startswith("/*", index):
                    depth += 1
                    index += 2
                elif query.startswith("*/", index):
                    depth -= 1
                    index += 2
                else:
                    index += 1
            continue

        line_comment = (
            query.startswith("--", index)
            or query.startswith("//", index)
            or (char == "#" and index + 1 < end and query[index + 1] in (" ", "!"))
        )
        if line_comment:
            newline = query.find("\n", index + 1)
            index = end if newline == -1 else newline + 1
            continue

        if char == "$":
            for marker_key in marker_keys:
                if query.startswith(marker_key, index):
                    raw_markers.setdefault(marker_key, set()).add(index)
            opener = _heredoc_re.match(query, index)
            if opener is not None:
                tag = opener.group()
                if last_heredoc_starts[tag] >= opener.end():
                    close = query.find(tag, opener.end())
                    index = close + len(tag)
                    continue

        if char == "{":
            match = external_bind_re.match(query, index)
            if match is not None:
                match_end = match.end()
                name_start, name_end = match.span(1)
                # A marker inside a placeholder can still open a server heredoc, except
                # mid-name, where the server lexes the whole name as one bareword.
                for marker_key in marker_keys:
                    found = query.find(marker_key, index, match_end)
                    while found != -1:
                        if not name_start < found < name_end:
                            raw_markers.setdefault(marker_key, set()).add(found)
                        found = query.find(marker_key, found + 1, match_end)
                matches.append(match)
                index = match_end
                continue

        if char == "_" or "A" <= char <= "Z" or "a" <= char <= "z":
            index += 1
            while index < end and _is_ascii_bareword_char(query[index]):
                index += 1
            continue

        if "0" <= char <= "9":
            index += 1
            while index < end and "0" <= query[index] <= "9":
                index += 1
            # Digit-led tokens promote to a bareword through word chars only, never `$`.
            if index < end and (query[index] == "_" or "A" <= query[index] <= "Z" or "a" <= query[index] <= "z"):
                index += 1
                while index < end and _is_ascii_word_char(query[index]):
                    index += 1
            continue

        if char == "$":
            token_end = index + 1
            if token_end < end and _is_ascii_word_char(query[token_end]):
                token_end += 1
                while token_end < end and _is_ascii_bareword_char(query[token_end]):
                    token_end += 1
                index = token_end
            else:
                # Lone DollarSign token, retry heredoc detection at the next character.
                index += 1
            continue

        index += 1
    return matches, raw_markers


def _binary_bind_value(value: Any) -> Any:
    # Buffer values splice into the query bytes uncopied, so return the original object.
    if isinstance(value, bytes):
        return value
    if isinstance(value, int):
        return None
    try:
        memoryview(value)
    except (TypeError, ValueError):
        return None
    return value


def _binary_bind_values(parameters: dict[str, Any]) -> dict[str, Any]:
    binary_binds = {}
    for key, value in parameters.items():
        if _is_binary_bind_name(key):
            binary_value = _binary_bind_value(value)
            if binary_value is not None:
                binary_binds[key] = binary_value
    return binary_binds


# Openers of tokens the SQL lexer skips or treats as opaque. An opaque span can only hide a
# placeholder that starts after it opens, so without an opener before the last raw match the
# raw regex and the token scan agree and routing skips the token loop.
_opaque_sql_opener_re = re.compile("[" + re.escape("".join(_quote_closers) + "".join(_curly_quote_closers) + "$") + r"]|/\*|--|//|#[ !]")


def _server_bind_matches(query: str, binary_names: Collection[str]) -> list[tuple[str, str]]:
    raw_matches = list(external_bind_re.finditer(query))
    if not raw_matches:
        return []
    filtered = [(match.group(1), match.group(2)) for match in raw_matches if match.group(1) not in binary_names]
    last_end = raw_matches[-1].end()
    if _opaque_sql_opener_re.search(query, 0, last_end) is None:
        return filtered

    # Each binary marker becomes its own heredoc after substitution, so it never opens one here.
    heredoc_ends = (
        {match.group(1): match.start() for match in _heredoc_start_re.finditer(query) if match.group(1) not in binary_names}
        if "$" in query
        else {}
    )
    matches = []
    index = 0
    while index < last_end:
        token, token_end = _next_sql_token(query, index, heredoc_ends)
        if token == _SQL_TOKEN_INVALID:
            return filtered
        if token == _SQL_TOKEN_TRIVIA:
            index = token_end
            continue
        if query[index] == "{":
            match = external_bind_re.fullmatch(query, index, token_end)
            if match is not None and match.group(1) not in binary_names:
                matches.append((match.group(1), match.group(2)))
        index = token_end
    return matches


def _binding_keeps_query_structure(query: str, parameters: Sequence | dict[str, Any] | None) -> bool:
    if not parameters:
        return True
    if not isinstance(parameters, dict):
        return False
    binary_names = _binary_bind_values(parameters).keys()
    has_server_bind = bool(_server_bind_matches(query, binary_names))
    return has_server_bind or len(binary_names) == len(parameters) or "%" not in query


def _binding_has_binary_values(parameters: Sequence | dict[str, Any] | None) -> bool:
    return isinstance(parameters, dict) and bool(_binary_bind_values(parameters))


def _heredoc_collision_error(key: str) -> ProgrammingError:
    return ProgrammingError(
        f"Query parameter name {key!r} also appears elsewhere in the query text, and ClickHouse "
        "would parse the pair of names as a heredoc string. Rename the parameter or remove the "
        "other occurrence."
    )


def _datetime_is_aware(value: datetime) -> bool:
    return value.utcoffset() is not None


def _legacy_naive_datetime_binding() -> bool:
    return common.get_setting("naive_datetime_binding") == "legacy"


class DT64Param:
    tz: tzinfo | None = None

    def __init__(self, value: datetime, tz: tzinfo | None = None):
        self.value = value
        self.tz = tz

    def format(self, tz: tzinfo | None, top_level: bool) -> str:
        if self.tz is not None:
            tz = self.tz
        value = self.value
        if _legacy_naive_datetime_binding():
            if tz:
                value = value.astimezone(tz)
        elif tz is not None and _datetime_is_aware(value):
            value = value.astimezone(tz)
        return self._render(value, top_level)

    @staticmethod
    def _render(value: datetime, top_level: bool) -> str:
        rendered = value.strftime("%Y-%m-%d %H:%M:%S.%f")
        nanosecond = getattr(value, "nanosecond", 0)
        if nanosecond:
            rendered += f"{nanosecond:03d}"
        return rendered if top_level else f"'{rendered}'"


def quote_identifier(identifier: str) -> str:
    if len(identifier) >= 2:
        quote = identifier[0]
        if quote in ("`", '"') and identifier[-1] == quote and _is_validly_quoted(identifier, quote):
            return identifier
    return _format_identifier(identifier)


def _qualified_table(table: str, database: str | None = None) -> str:
    # Dotted names stay as-is so existing db.table callers keep working.
    if "." in table:
        return table
    if database:
        return f"{quote_identifier(database)}.{quote_identifier(table)}"
    return quote_identifier(table)


def _format_identifier(identifier: str) -> str:
    """Format a decoded identifier value, including literal boundary quotes."""
    return f"`{escape_str(identifier)}`"


def _is_validly_quoted(identifier: str, quote: str) -> bool:
    # Accepts backslash escapes (\X) and doubled-quote escapes (`` or "").
    i, end = 1, len(identifier) - 1
    while i < end:
        c = identifier[i]
        if c == "\\":
            if i + 1 >= end:
                return False
            i += 2
        elif c == quote:
            if i + 1 < end and identifier[i + 1] == quote:
                i += 2
            else:
                return False
        else:
            i += 1
    return True


def finalize_query(query: str, parameters: Sequence | dict[str, Any] | None, server_tz: tzinfo | None = None) -> str:
    query = query.rstrip(";")
    if not parameters:
        return query
    if hasattr(parameters, "items"):
        return query % {k: format_query_value(v, server_tz) for k, v in parameters.items()}
    return query % tuple(format_query_value(v, server_tz) for v in parameters)


# Cached because containers unwrap the same element type for every value
@lru_cache(maxsize=256)
def _unwrap_outer(type_str: str) -> tuple[str, tuple]:
    """Strip LowCardinality/Nullable wrappers and return (base_name, args)"""
    base = type_str.strip()
    while True:
        base_name, values, _ = parse_callable(base)
        if base_name.lower() not in ("lowcardinality", "nullable") or len(values) != 1:
            return base_name, values
        base = str(values[0])


@lru_cache(maxsize=256)
def _container_element_types(type_str: str) -> tuple[str, ...]:
    """Parse Tuple or Nested element types."""
    return _container_columns(type_str)[1]


@lru_cache(maxsize=256)
def _container_columns(type_str: str) -> tuple[tuple[str, ...], tuple[str, ...]]:
    _, values = _unwrap_outer(type_str)
    return parse_columns(f"({', '.join(str(t).strip() for t in values)})")


def _named_tuple_values(names: tuple[str, ...], value: Mapping) -> tuple:
    missing = [name for name in names if name not in value]
    unexpected = [name for name in value if name not in names]
    if missing or unexpected:
        raise ProgrammingError(f"Named Tuple fields do not match: missing {missing!r}, unexpected {unexpected!r}")
    return tuple(value[name] for name in names)


def _normalize_named_tuples(type_str: str, value: Any) -> Any:
    """Put mapping values in the declared order of named Tuple fields."""
    if value is None or "tuple" not in type_str.lower():
        return value
    try:
        base_name, types = _unwrap_outer(type_str)
        base_name = base_name.lower()
        columns = _container_columns(type_str) if base_name == "tuple" else None
    except Exception:
        return value
    if columns is not None:
        names, element_types = columns
        if names and isinstance(value, Mapping):
            value = _named_tuple_values(names, value)
        if isinstance(value, tuple) and len(value) == len(element_types):
            return tuple(_normalize_named_tuples(t, item) for t, item in zip(element_types, value))
    elif base_name == "array" and types and isinstance(value, (list, tuple)):
        items = (_normalize_named_tuples(str(types[0]), item) for item in value)
        return tuple(items) if isinstance(value, tuple) else list(items)
    elif base_name == "map" and len(types) == 2 and isinstance(value, dict) and common.get_setting("dict_parameter_format") == "map":
        key_type, value_type = (str(t) for t in types)
        return {_normalize_named_tuples(key_type, key): _normalize_named_tuples(value_type, item) for key, item in value.items()}
    return value


@lru_cache(maxsize=256)
def _mentions_datetime(type_str: str) -> bool:
    """Find datetime types without counting field names or enum labels."""
    base_name, values = _unwrap_outer(type_str)
    base_name = base_name.lower()
    if base_name in ("datetime", "datetime32", "datetime64"):
        return True
    if base_name in ("tuple", "nested"):
        return any(_mentions_datetime(t) for t in _container_element_types(type_str))
    if base_name in ("array", "map", "variant", "nullable", "lowcardinality"):
        return any(_mentions_datetime(str(t)) for t in values)
    return False


def _extract_tz_from_type(type_str: str) -> tzinfo | None:
    """Resolve the timezone named in a ClickHouse type hint."""
    try:
        base_name, values = _unwrap_outer(type_str)
        if base_name.lower() in ("datetime", "datetime64"):
            for v in values:
                if isinstance(v, str) and v.startswith("'") and v.endswith("'"):
                    try:
                        return tzutil.resolve_zone(v[1:-1])
                    except zoneinfo.ZoneInfoNotFoundError:
                        return None
            return None

        if values:
            for v in values:
                if isinstance(v, str):
                    tz = _extract_tz_from_type(v)
                    if tz is not None:
                        return tz

        return None
    except Exception:
        return None


@lru_cache(maxsize=256)
def _datetime64_type_tz(type_str: str) -> tzinfo | None:
    """Cached _extract_tz_from_type, since containers resolve the same element type for every value."""
    return _extract_tz_from_type(type_str)


def _promote_datetime64(type_str: str, value):
    """Wrap values bound to a DateTime64 hint in DT64Param to preserve precision."""
    if value is None or "datetime64" not in type_str.lower():
        return value
    try:
        base_name, values = _unwrap_outer(type_str)
        base_name = base_name.lower()
        if base_name == "variant" and isinstance(value, (datetime, DT64Param)):
            datetime_alts = [str(t) for t in values if _mentions_datetime(str(t))]
            if len(datetime_alts) == 1 and _unwrap_outer(datetime_alts[0])[0].lower() == "datetime64":
                return _promote_datetime64(datetime_alts[0], value)
        if base_name == "datetime64":
            tz = _datetime64_type_tz(type_str)
            if isinstance(value, datetime):
                return DT64Param(value, tz)
            if isinstance(value, DT64Param) and value.tz is None and tz is not None:
                promoted = copy.copy(value)
                promoted.tz = tz
                return promoted
            return value
        if base_name == "array" and values and isinstance(value, (list, tuple)):
            inner = str(values[0])
            return type(value)(_promote_datetime64(inner, x) for x in value)
        if base_name == "tuple" and isinstance(value, tuple):
            element_types = _container_element_types(type_str)
            if len(element_types) == len(value):
                return tuple(_promote_datetime64(t, x) for t, x in zip(element_types, value))
        if base_name == "nested" and isinstance(value, (list, tuple)):
            element_types = _container_element_types(type_str)
            element_type = f"Tuple({', '.join(element_types)})"
            return type(value)(_promote_datetime64(element_type, x) for x in value)
        if base_name == "map" and isinstance(value, dict) and len(values) == 2 and common.get_setting("dict_parameter_format") == "map":
            key_type, value_type = (str(t) for t in values)
            return {_promote_datetime64(key_type, k): _promote_datetime64(value_type, v) for k, v in value.items()}
        return value
    except Exception:
        return value


def _pyformat_bind_names(query: str) -> set[str]:
    """Read mapping keys using Python percent formatting rules."""
    names: set[str] = set()
    index = query.find("%")
    end = len(query)
    while index != -1:
        index += 1
        if query.startswith("%", index):
            index += 1
        elif query.startswith("(", index):
            start = index + 1
            index = start
            depth = 1
            while index < end and depth:
                char = query[index]
                if char == "(":
                    depth += 1
                elif char == ")":
                    depth -= 1
                index += 1
            if depth == 0:
                names.add(query[start : index - 1])
        index = query.find("%", index)
    return names


def bind_query(
    query: str,
    parameters: Sequence | dict[str, Any] | None,
    server_tz: tzinfo | None = None,
) -> tuple[str | bytes, dict[str, str]]:
    query = query.rstrip(";")
    if not parameters:
        return query, {}

    binary_binds = None
    bound_params: dict[str, str] = {}

    if isinstance(parameters, dict):
        params_copy = dict_copy(parameters)
        binary_binds = _binary_bind_values(params_copy)
        nonbinary_marker_keys = set()
        for key in params_copy:
            if _is_binary_bind_name(key) and key not in binary_binds:
                nonbinary_marker_keys.add(key)
        for key in binary_binds.keys():
            del params_copy[key]

        # Validate non-buffer `$name$` keys against server heredoc parsing.
        if nonbinary_marker_keys and any(key in query for key in nonbinary_marker_keys):
            match_objects, raw_markers = _external_bind_matches(query, nonbinary_marker_keys)
            for key in params_copy:
                if key not in nonbinary_marker_keys:
                    continue
                placeholder_spans = [match.span(1) for match in match_objects if match.group(1) == key]
                if len(placeholder_spans) > 1:
                    raise ProgrammingError(
                        f"Server-side query parameter {key!r} can appear only once because repeated "
                        "dollar-delimited names are parsed as a heredoc string. Rename the parameter."
                    )
                raw_marker_starts = raw_markers.get(key, set())
                if placeholder_spans:
                    placeholder_start, placeholder_end = placeholder_spans[0]
                    if any(start < placeholder_start for start in raw_marker_starts) or query.find(key, placeholder_end) != -1:
                        raise _heredoc_collision_error(key)
                elif raw_marker_starts:
                    if f"{{{key}:" in query:
                        # The user wrote a placeholder, but an earlier heredoc pairing swallowed it.
                        raise _heredoc_collision_error(key)
                    raise ProgrammingError(
                        f"Binary query parameter {key!r} must be a buffer value such as bytes, bytearray, or memoryview. "
                        "Use a valid {name:Type} placeholder for server-side binding."
                    )

        binary_names = binary_binds.keys()
        matches = _server_bind_matches(query, binary_names)
        placeholder_names: set[str] | None = None
        final_params = {}
        for k, v in params_copy.items():
            # The _64 suffix is a precision hint, not part of the name, unless the
            # query binds the full name itself.
            if k.endswith("_64") and (isinstance(v, datetime) or (isinstance(v, list) and len(v) > 0 and isinstance(v[0], datetime))):
                referenced = False
                if k in query:
                    if placeholder_names is None:
                        placeholder_names = {name for name, _ in matches} if matches else _pyformat_bind_names(query)
                    referenced = k in placeholder_names
                if not referenced:
                    k = k[:-3]
                    v = DT64Param(v) if isinstance(v, datetime) else [DT64Param(x) for x in v]
            final_params[k] = v
        if not matches:
            query, bound_params = finalize_query(query, final_params, server_tz), {}
        else:
            param_types = {}
            for name, matched_type in matches:
                if name not in param_types:
                    param_types[name] = matched_type
            bound_params = {}
            for k, v in final_params.items():
                tz = server_tz
                param_type = param_types.get(k)
                if param_type is not None:
                    v = _normalize_named_tuples(param_type, v)
                    hint_tz = _extract_tz_from_type(param_type)
                    if hint_tz is not None:
                        tz = hint_tz
                    v = _promote_datetime64(param_type, v)
                bound_params[f"param_{k}"] = format_bind_value(v, tz)
    else:
        query, bound_params = finalize_query(query, parameters, server_tz), {}
    if binary_binds:
        binary_query = query.encode()
        binary_indexes = {}
        for k, v in binary_binds.items():
            key = k.encode()
            item_index = 0
            while True:
                item_index = binary_query.find(key, item_index)
                if item_index == -1:
                    break
                binary_indexes[item_index + len(key)] = key, v
                item_index += len(key)
        binary_out = b""
        start = 0
        for loc in sorted(binary_indexes.keys()):
            key, value = binary_indexes[loc]
            binary_out += binary_query[start:loc] + value + key
            start = loc
        binary_out += binary_query[start:]
        return binary_out, bound_params
    return query, bound_params


# Server-side bind parameters are urlencoded into the request URL. Once the encoded length
# passes this budget the client routes them through multipart form data instead, keeping
# oversized payloads out of the URL where proxies (nginx, ALB, CloudFront) reject them with
# HTTP 414. The threshold leaves ample headroom under common request line limits.
MAX_URL_BIND_PARAM_LENGTH = 4096

# The form path moves the SQL itself into a "query" field, which the server caps at
# http_max_field_value_size (128 KiB by default) while the body path has no such limit.
# The server accepts one byte past that setting. Measure the final SQL, including any
# appended LIMIT and FORMAT clauses.
MAX_FORM_QUERY_BYTES = 128 * 1024 + 1


def use_form_encoding(query: str | bytes, bind_params: dict[str, str], force_form: bool = False) -> bool:
    if force_form:
        return True
    # Binary binds embed bytes into the query, which the form path cannot round-trip; leave
    # those on the default path unless form encoding is explicitly requested.
    if isinstance(query, bytes):
        return False
    if not bind_params:
        return False
    # Promoting a query too large for a form field trades a possible URL rejection for a
    # certain server rejection, so keep it on the default path. UTF-8 uses at most four bytes
    # per character, so only encode when the query could be over the limit.
    if len(query) > MAX_FORM_QUERY_BYTES // 4 and len(query.encode()) > MAX_FORM_QUERY_BYTES:
        return False
    # Raw length is a lower bound on the encoded length, so large payloads short-circuit
    # without materializing the encoded string.
    if sum(len(k) + len(str(v)) for k, v in bind_params.items()) > MAX_URL_BIND_PARAM_LENGTH:
        return True
    # Measure with quote so spaces count as %20, matching the longer of the two client encodings.
    return len(urlencode(bind_params, quote_via=quote)) > MAX_URL_BIND_PARAM_LENGTH


def _format_time_of_day(value: time | timedelta) -> str:
    """Format a time or timedelta as the [-]HH:MM:SS[.ffffff|.fffffffff] literal used by Time/Time64."""

    if isinstance(value, time):
        base = f"{value.hour:02d}:{value.minute:02d}:{value.second:02d}"
        nanos = value.microsecond * 1_000
    else:
        total_nanos = (value.days * 86400 + value.seconds) * 1_000_000_000 + value.microseconds * 1_000 + getattr(value, "nanoseconds", 0)
        sign = "-" if total_nanos < 0 else ""
        total_seconds, nanos = divmod(abs(total_nanos), 1_000_000_000)
        hours, remainder = divmod(total_seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        base = f"{sign}{hours:02d}:{minutes:02d}:{seconds:02d}"
    if nanos % 1_000:
        return f"{base}.{nanos:09d}"
    if nanos:
        return f"{base}.{nanos // 1_000:06d}"
    return base


def format_str(value: str):
    return f"'{escape_str(value)}'"


_CH_STRING_ESCAPES = {"\\": "\\", "'": "'", '"': '"', "`": "`", "n": "\n", "t": "\t", "r": "\r", "b": "\b", "f": "\f", "0": "\0"}


def _decode_ch_string_literal(literal: str) -> str:
    inner = literal[1:-1].replace("''", "'")
    out: list[str] = []
    i = 0
    while i < len(inner):
        ch = inner[i]
        if ch == "\\" and i + 1 < len(inner):
            out.append(_CH_STRING_ESCAPES.get(inner[i + 1], inner[i + 1]))
            i += 2
        else:
            out.append(ch)
            i += 1
    return "".join(out)


def escape_str(value: str):
    return value.translate(_STR_ESCAPES)


def escape_bytes(value):
    return "".join([_BYTE_ESCAPES[b] for b in value])


def format_query_value(value: Any, server_tz: tzinfo | None = timezone.utc):
    """
    Format Python values in a ClickHouse query
    :param value: Python object
    :param server_tz: Server timezone for adjusting datetime values
    :return: Literal string for python value
    """
    if value is None:
        return "NULL"
    if isinstance(value, str):
        return format_str(value)
    if isinstance(value, (bytes, bytearray)):
        return f"'{escape_bytes(value)}'"
    if isinstance(value, DT64Param):
        return value.format(server_tz, False)
    if isinstance(value, datetime):
        if _legacy_naive_datetime_binding():
            if value.tzinfo is not None or not tzutil.is_utc_timezone(server_tz):
                value = value.astimezone(server_tz)
        elif _datetime_is_aware(value):
            value = value.astimezone(server_tz)
        return f"'{value.strftime('%Y-%m-%d %H:%M:%S')}'"
    if isinstance(value, date):
        return f"'{value.isoformat()}'"
    if isinstance(value, (time, timedelta)):
        return f"'{_format_time_of_day(value)}'"
    if isinstance(value, list):
        return f"[{', '.join(str_query_value(x, server_tz) for x in value)}]"
    if isinstance(value, tuple):
        return f"({', '.join(str_query_value(x, server_tz) for x in value)})"
    if isinstance(value, dict):
        if common.get_setting("dict_parameter_format") == "json":
            return format_str(any_to_json(value).decode())
        pairs = [str_query_value(k, server_tz) + ":" + str_query_value(v, server_tz) for k, v in value.items()]
        return f"{{{', '.join(pairs)}}}"
    if isinstance(value, Enum):
        return format_query_value(value.value, server_tz)
    if isinstance(value, (uuid.UUID, ipaddress.IPv4Address, ipaddress.IPv6Address)):
        return f"'{value}'"
    return value


def str_query_value(value: Any, server_tz: tzinfo | None = timezone.utc):
    return str(format_query_value(value, server_tz))


def format_bind_value(value: Any, server_tz: tzinfo | None = timezone.utc, top_level: bool = True):
    """
    Format Python values in a ClickHouse query
    :param value: Python object
    :param server_tz: Server timezone for adjusting datetime values
    :param top_level: Flag for top level for nested structures
    :return: Literal string for python value
    """

    def recurse(x):
        return format_bind_value(x, server_tz, False)

    if value is None:
        # Top-level NULL bind parameters use the escaped-text sentinel. Nested
        # container elements are parsed as SQL literals and must use NULL.
        return "\\N" if top_level else "NULL"
    if isinstance(value, str):
        if top_level:
            # At the top levels, strings must not be surrounded by quotes
            return escape_str(value)
        return format_str(value)
    if isinstance(value, (bytes, bytearray)):
        if top_level:
            return escape_bytes(value)
        return f"'{escape_bytes(value)}'"
    if isinstance(value, DT64Param):
        return value.format(server_tz, top_level)
    if isinstance(value, datetime):
        if _legacy_naive_datetime_binding() or _datetime_is_aware(value):
            value = value.astimezone(server_tz)
        val = value.strftime("%Y-%m-%d %H:%M:%S")
        if top_level:
            return val
        return f"'{val}'"
    if isinstance(value, date):
        if top_level:
            return value.isoformat()
        return f"'{value.isoformat()}'"
    if isinstance(value, (time, timedelta)):
        val = _format_time_of_day(value)
        if top_level:
            return val
        return f"'{val}'"
    if isinstance(value, list):
        return f"[{', '.join(recurse(x) for x in value)}]"
    if isinstance(value, tuple):
        return f"({', '.join(recurse(x) for x in value)})"
    if isinstance(value, dict):
        if common.get_setting("dict_parameter_format") == "json":
            return any_to_json(value).decode()
        pairs = [recurse(k) + ":" + recurse(v) for k, v in value.items()]
        return f"{{{', '.join(pairs)}}}"
    if isinstance(value, Enum):
        return format_bind_value(value.value, server_tz, top_level)
    if isinstance(value, (uuid.UUID, ipaddress.IPv4Address, ipaddress.IPv6Address)):
        if top_level:
            return str(value)
        return f"'{value}'"
    return str(value)
