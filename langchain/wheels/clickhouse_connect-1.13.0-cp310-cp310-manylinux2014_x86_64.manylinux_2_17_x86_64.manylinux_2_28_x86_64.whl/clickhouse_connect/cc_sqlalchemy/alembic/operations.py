from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any

from alembic.operations import MigrateOperation, Operations
from alembic.operations.ops import ModifyTableOps
from sqlalchemy import Column

from clickhouse_connect.cc_sqlalchemy.ddl.index import ClickHouseIndex, index_definition
from clickhouse_connect.cc_sqlalchemy.ddl.projection import ClickHouseProjection, projection_definition
from clickhouse_connect.cc_sqlalchemy.sql import full_table
from clickhouse_connect.cc_sqlalchemy.sql.ddlcompiler import column_specification, render_settings
from clickhouse_connect.driver.binding import format_str, quote_identifier

__all__ = [
    "AddClickHouseIndexOp",
    "AddClickHouseIndexesOp",
    "DropClickHouseIndexOp",
    "DropClickHouseIndexesOp",
    "MaterializeClickHouseIndexOp",
    "AddClickHouseProjectionOp",
    "AddClickHouseProjectionsOp",
    "DropClickHouseProjectionOp",
    "DropClickHouseProjectionsOp",
    "MaterializeClickHouseProjectionOp",
    "ModifyClickHouseTableSettingsOp",
    "ResetClickHouseTableSettingsOp",
    "CreateClickHouseViewOp",
    "DropClickHouseViewOp",
    "CreateClickHouseFunctionOp",
    "DropClickHouseFunctionOp",
    "CreateClickHouseMaterializedViewOp",
    "DropClickHouseMaterializedViewOp",
    "CreateClickHouseDictionaryOp",
    "DropClickHouseDictionaryOp",
    "ReloadClickHouseDictionaryOp",
    "ClickHouseIndex",
    "ClickHouseProjection",
]


def _validate_position(first: bool, after_name: str | None, owner: str) -> None:
    if first and after_name is not None:
        raise ValueError(f"{owner} cannot specify both first and after placement")


def _exec_sql(operations: Operations, sql: str, *, literal_sql: bool = False) -> None:
    impl = operations.get_context().impl
    if impl.as_sql:
        impl.static_output(sql.strip() + impl.command_terminator)
        return

    connection = impl.connection
    assert connection is not None
    # DB-API pyformat processing otherwise collapses literal double percent signs.
    connection.exec_driver_sql(sql.replace("%", "%%") if literal_sql else sql)


def _settings_suffix(clickhouse_settings: Mapping[str, Any] | None) -> str:
    rendered = render_settings(clickhouse_settings)
    return f" SETTINGS {rendered}" if rendered else ""


def _render_column_list(operations: Operations, columns: Sequence[Column[Any]]) -> str:
    dialect = operations.get_context().dialect
    return ", ".join(column_specification(dialect, column) for column in columns)


def _render_add_index(index: ClickHouseIndex) -> str:
    parts = ["ADD INDEX"]
    if index.if_not_exists:
        parts.append("IF NOT EXISTS")
    parts.append(index_definition(index))
    if index.first:
        parts.append("FIRST")
    elif index.after_index is not None:
        parts.append(f"AFTER {quote_identifier(index.after_index)}")
    return " ".join(parts)


def _render_add_projection(projection: ClickHouseProjection) -> str:
    parts = ["ADD PROJECTION"]
    if projection.if_not_exists:
        parts.append("IF NOT EXISTS")
    parts.append(projection_definition(projection))
    if projection.first:
        parts.append("FIRST")
    elif projection.after_projection is not None:
        parts.append(f"AFTER {quote_identifier(projection.after_projection)}")
    return " ".join(parts)


@Operations.register_operation("add_clickhouse_index")
class AddClickHouseIndexOp(MigrateOperation):
    def __init__(
        self,
        table_name: str,
        name: str,
        expression: str,
        type_: str,
        *,
        granularity: int | None = None,
        if_not_exists: bool = False,
        first: bool = False,
        after_index: str | None = None,
        schema: str | None = None,
        clickhouse_settings: Mapping[str, Any] | None = None,
    ) -> None:
        _validate_position(first, after_index, "_AddClickHouseIndexOp")
        self.table_name: str = table_name
        self.name: str = name
        self.expression: str = expression
        self.type_: str = type_
        self.granularity: int | None = granularity
        self.if_not_exists: bool = if_not_exists
        self.first: bool = first
        self.after_index: str | None = after_index
        self.schema: str | None = schema
        self.clickhouse_settings: Mapping[str, Any] | None = clickhouse_settings

    @classmethod
    def add_clickhouse_index(
        cls,
        operations: Operations,
        table_name: str,
        name: str,
        expression: str,
        type_: str,
        granularity: int | None = None,
        if_not_exists: bool = False,
        first: bool = False,
        after_index: str | None = None,
        schema: str | None = None,
        clickhouse_settings: Mapping[str, Any] | None = None,
    ) -> Any:
        """Emit ALTER TABLE ... ADD INDEX.

        expression and type_ are raw SQL passthrough. Metadata-only: no mutation is
        scheduled and existing parts are not backfilled, so no sync setting applies.
        Call materialize_clickhouse_index to backfill existing parts.
        """
        return operations.invoke(
            cls(
                table_name,
                name,
                expression,
                type_,
                granularity=granularity,
                if_not_exists=if_not_exists,
                first=first,
                after_index=after_index,
                schema=schema,
                clickhouse_settings=clickhouse_settings,
            )
        )

    def reverse(self) -> MigrateOperation:
        return DropClickHouseIndexOp(
            self.table_name,
            self.name,
            if_exists=True,
            schema=self.schema,
            clickhouse_settings=self.clickhouse_settings,
            existing_index=ClickHouseIndex(self.name, self.expression, self.type_, self.granularity),
        )


@Operations.implementation_for(AddClickHouseIndexOp)
def _add_clickhouse_index(operations: Operations, operation: AddClickHouseIndexOp) -> Any:
    index = ClickHouseIndex(
        name=operation.name,
        expression=operation.expression,
        type_=operation.type_,
        granularity=operation.granularity,
        if_not_exists=operation.if_not_exists,
        first=operation.first,
        after_index=operation.after_index,
    )
    ft = full_table(operation.table_name, operation.schema)
    sql = f"ALTER TABLE {ft} {_render_add_index(index)}{_settings_suffix(operation.clickhouse_settings)}"
    return _exec_sql(operations, sql)


@Operations.register_operation("add_clickhouse_indexes")
class AddClickHouseIndexesOp(MigrateOperation):
    def __init__(
        self,
        table_name: str,
        indexes: Sequence[ClickHouseIndex],
        *,
        schema: str | None = None,
        clickhouse_settings: Mapping[str, Any] | None = None,
    ) -> None:
        self.table_name: str = table_name
        self.indexes: tuple[ClickHouseIndex, ...] = tuple(indexes)
        if not self.indexes:
            raise ValueError("add_clickhouse_indexes requires at least one index")
        self.schema: str | None = schema
        self.clickhouse_settings: Mapping[str, Any] | None = clickhouse_settings

    @classmethod
    def add_clickhouse_indexes(
        cls,
        operations: Operations,
        table_name: str,
        indexes: Sequence[ClickHouseIndex],
        schema: str | None = None,
        clickhouse_settings: Mapping[str, Any] | None = None,
    ) -> Any:
        """Emit ONE comma-joined ALTER TABLE ... ADD INDEX, ADD INDEX ... statement.

        This is the fix for Code 517 CANNOT_ASSIGN_ALTER races on replicated deployments.
        Combining the subcommands is safe on both plain and Replicated databases because
        every subcommand is a homogeneous pure-metadata alter. Metadata-only: no mutation
        is scheduled, so no sync setting applies. Call materialize_clickhouse_index per
        index to backfill existing parts.
        """
        return operations.invoke(
            cls(
                table_name,
                indexes,
                schema=schema,
                clickhouse_settings=clickhouse_settings,
            )
        )

    def reverse(self) -> MigrateOperation:
        return DropClickHouseIndexesOp(
            self.table_name,
            [index.name for index in self.indexes],
            if_exists=True,
            schema=self.schema,
            clickhouse_settings=self.clickhouse_settings,
        )


@Operations.implementation_for(AddClickHouseIndexesOp)
def _add_clickhouse_indexes(operations: Operations, operation: AddClickHouseIndexesOp) -> Any:
    ft = full_table(operation.table_name, operation.schema)
    subcommands = ", ".join(_render_add_index(index) for index in operation.indexes)
    sql = f"ALTER TABLE {ft} {subcommands}{_settings_suffix(operation.clickhouse_settings)}"
    return _exec_sql(operations, sql)


@Operations.register_operation("drop_clickhouse_index")
class DropClickHouseIndexOp(MigrateOperation):
    def __init__(
        self,
        table_name: str,
        name: str,
        *,
        if_exists: bool = False,
        schema: str | None = None,
        clickhouse_settings: Mapping[str, Any] | None = None,
        existing_index: ClickHouseIndex | None = None,
    ) -> None:
        self.table_name: str = table_name
        self.name: str = name
        self.if_exists: bool = if_exists
        self.schema: str | None = schema
        self.clickhouse_settings: Mapping[str, Any] | None = clickhouse_settings
        self.existing_index: ClickHouseIndex | None = existing_index

    def reverse(self) -> MigrateOperation:
        index = self.existing_index
        if index is None:
            return super().reverse()
        return AddClickHouseIndexOp(
            self.table_name,
            index.name,
            index.expression,
            index.type_,
            granularity=index.granularity,
            schema=self.schema,
            clickhouse_settings=self.clickhouse_settings,
        )

    @classmethod
    def drop_clickhouse_index(
        cls,
        operations: Operations,
        table_name: str,
        name: str,
        if_exists: bool = False,
        schema: str | None = None,
        clickhouse_settings: Mapping[str, Any] | None = None,
    ) -> Any:
        """Emit ALTER TABLE ... DROP INDEX.

        Schedules a mutation governed by alter_sync (recommend 0, 1, or 2), not mutations_sync.
        """
        return operations.invoke(
            cls(
                table_name,
                name,
                if_exists=if_exists,
                schema=schema,
                clickhouse_settings=clickhouse_settings,
            )
        )


@Operations.implementation_for(DropClickHouseIndexOp)
def _drop_clickhouse_index(operations: Operations, operation: DropClickHouseIndexOp) -> Any:
    ft = full_table(operation.table_name, operation.schema)
    exists = "IF EXISTS " if operation.if_exists else ""
    sql = f"ALTER TABLE {ft} DROP INDEX {exists}{quote_identifier(operation.name)}{_settings_suffix(operation.clickhouse_settings)}"
    return _exec_sql(operations, sql)


@Operations.register_operation("drop_clickhouse_indexes")
class DropClickHouseIndexesOp(MigrateOperation):
    def __init__(
        self,
        table_name: str,
        names: Sequence[str],
        *,
        if_exists: bool = False,
        schema: str | None = None,
        clickhouse_settings: Mapping[str, Any] | None = None,
    ) -> None:
        self.table_name: str = table_name
        self.names: tuple[str, ...] = tuple(names)
        if not self.names:
            raise ValueError("drop_clickhouse_indexes requires at least one index name")
        self.if_exists: bool = if_exists
        self.schema: str | None = schema
        self.clickhouse_settings: Mapping[str, Any] | None = clickhouse_settings

    @classmethod
    def drop_clickhouse_indexes(
        cls,
        operations: Operations,
        table_name: str,
        names: Sequence[str],
        if_exists: bool = False,
        schema: str | None = None,
        clickhouse_settings: Mapping[str, Any] | None = None,
    ) -> Any:
        """Emit ONE comma-joined ALTER TABLE ... DROP INDEX, DROP INDEX ... statement."""
        return operations.invoke(
            cls(
                table_name,
                names,
                if_exists=if_exists,
                schema=schema,
                clickhouse_settings=clickhouse_settings,
            )
        )


@Operations.implementation_for(DropClickHouseIndexesOp)
def _drop_clickhouse_indexes(operations: Operations, operation: DropClickHouseIndexesOp) -> Any:
    ft = full_table(operation.table_name, operation.schema)
    exists = "IF EXISTS " if operation.if_exists else ""
    subcommands = ", ".join(f"DROP INDEX {exists}{quote_identifier(name)}" for name in operation.names)
    sql = f"ALTER TABLE {ft} {subcommands}{_settings_suffix(operation.clickhouse_settings)}"
    return _exec_sql(operations, sql)


@Operations.register_operation("materialize_clickhouse_index")
class MaterializeClickHouseIndexOp(MigrateOperation):
    def __init__(
        self,
        table_name: str,
        name: str,
        *,
        if_exists: bool = False,
        partition: str | None = None,
        schema: str | None = None,
        clickhouse_settings: Mapping[str, Any] | None = None,
    ) -> None:
        self.table_name: str = table_name
        self.name: str = name
        self.if_exists: bool = if_exists
        self.partition: str | None = partition
        self.schema: str | None = schema
        self.clickhouse_settings: Mapping[str, Any] | None = clickhouse_settings

    @classmethod
    def materialize_clickhouse_index(
        cls,
        operations: Operations,
        table_name: str,
        name: str,
        if_exists: bool = False,
        partition: str | None = None,
        schema: str | None = None,
        clickhouse_settings: Mapping[str, Any] | None = None,
    ) -> Any:
        """Emit ALTER TABLE ... MATERIALIZE INDEX to backfill existing parts.

        partition is raw SQL passthrough. Schedules a mutation governed by mutations_sync
        (recommend 0, 1, or 2). Kept as a separate statement by design: Replicated databases
        reject ADD INDEX and MATERIALIZE INDEX combined in one statement.
        """
        return operations.invoke(
            cls(
                table_name,
                name,
                if_exists=if_exists,
                partition=partition,
                schema=schema,
                clickhouse_settings=clickhouse_settings,
            )
        )


@Operations.implementation_for(MaterializeClickHouseIndexOp)
def _materialize_clickhouse_index(operations: Operations, operation: MaterializeClickHouseIndexOp) -> Any:
    ft = full_table(operation.table_name, operation.schema)
    exists = "IF EXISTS " if operation.if_exists else ""
    partition = f" IN PARTITION {operation.partition}" if operation.partition is not None else ""
    sql = (
        f"ALTER TABLE {ft} MATERIALIZE INDEX {exists}{quote_identifier(operation.name)}"
        f"{partition}{_settings_suffix(operation.clickhouse_settings)}"
    )
    return _exec_sql(operations, sql)


@Operations.register_operation("add_clickhouse_projection")
class AddClickHouseProjectionOp(MigrateOperation):
    def __init__(
        self,
        table_name: str,
        name: str,
        select: str,
        *,
        if_not_exists: bool = False,
        first: bool = False,
        after_projection: str | None = None,
        schema: str | None = None,
        clickhouse_settings: Mapping[str, Any] | None = None,
    ) -> None:
        _validate_position(first, after_projection, "_AddClickHouseProjectionOp")
        self.table_name: str = table_name
        self.name: str = name
        self.select: str = select
        self.if_not_exists: bool = if_not_exists
        self.first: bool = first
        self.after_projection: str | None = after_projection
        self.schema: str | None = schema
        self.clickhouse_settings: Mapping[str, Any] | None = clickhouse_settings

    @classmethod
    def add_clickhouse_projection(
        cls,
        operations: Operations,
        table_name: str,
        name: str,
        select: str,
        if_not_exists: bool = False,
        first: bool = False,
        after_projection: str | None = None,
        schema: str | None = None,
        clickhouse_settings: Mapping[str, Any] | None = None,
    ) -> Any:
        """Emit ALTER TABLE ... ADD PROJECTION.

        select is the raw SQL body placed inside the parens. Metadata-only: no mutation is
        scheduled and existing parts are not backfilled, so no sync setting applies. Call
        materialize_clickhouse_projection to backfill existing parts.
        """
        return operations.invoke(
            cls(
                table_name,
                name,
                select,
                if_not_exists=if_not_exists,
                first=first,
                after_projection=after_projection,
                schema=schema,
                clickhouse_settings=clickhouse_settings,
            )
        )

    def reverse(self) -> MigrateOperation:
        return DropClickHouseProjectionOp(
            self.table_name,
            self.name,
            if_exists=True,
            schema=self.schema,
            clickhouse_settings=self.clickhouse_settings,
            existing_projection=ClickHouseProjection(self.name, self.select),
        )


@Operations.implementation_for(AddClickHouseProjectionOp)
def _add_clickhouse_projection(operations: Operations, operation: AddClickHouseProjectionOp) -> Any:
    projection = ClickHouseProjection(
        name=operation.name,
        select=operation.select,
        if_not_exists=operation.if_not_exists,
        first=operation.first,
        after_projection=operation.after_projection,
    )
    ft = full_table(operation.table_name, operation.schema)
    sql = f"ALTER TABLE {ft} {_render_add_projection(projection)}{_settings_suffix(operation.clickhouse_settings)}"
    return _exec_sql(operations, sql)


@Operations.register_operation("add_clickhouse_projections")
class AddClickHouseProjectionsOp(MigrateOperation):
    def __init__(
        self,
        table_name: str,
        projections: Sequence[ClickHouseProjection],
        *,
        schema: str | None = None,
        clickhouse_settings: Mapping[str, Any] | None = None,
    ) -> None:
        self.table_name: str = table_name
        self.projections: tuple[ClickHouseProjection, ...] = tuple(projections)
        if not self.projections:
            raise ValueError("add_clickhouse_projections requires at least one projection")
        self.schema: str | None = schema
        self.clickhouse_settings: Mapping[str, Any] | None = clickhouse_settings

    @classmethod
    def add_clickhouse_projections(
        cls,
        operations: Operations,
        table_name: str,
        projections: Sequence[ClickHouseProjection],
        schema: str | None = None,
        clickhouse_settings: Mapping[str, Any] | None = None,
    ) -> Any:
        """Emit ONE comma-joined ALTER TABLE ... ADD PROJECTION, ADD PROJECTION ... statement.

        This is the fix for Code 517 CANNOT_ASSIGN_ALTER races on replicated deployments.
        Combining the subcommands is safe on both plain and Replicated databases because
        every subcommand is a homogeneous pure-metadata alter. Metadata-only: no mutation
        is scheduled, so no sync setting applies. Call materialize_clickhouse_projection per
        projection to backfill existing parts.
        """
        return operations.invoke(
            cls(
                table_name,
                projections,
                schema=schema,
                clickhouse_settings=clickhouse_settings,
            )
        )

    def reverse(self) -> MigrateOperation:
        return DropClickHouseProjectionsOp(
            self.table_name,
            [projection.name for projection in self.projections],
            if_exists=True,
            schema=self.schema,
            clickhouse_settings=self.clickhouse_settings,
        )


@Operations.implementation_for(AddClickHouseProjectionsOp)
def _add_clickhouse_projections(operations: Operations, operation: AddClickHouseProjectionsOp) -> Any:
    ft = full_table(operation.table_name, operation.schema)
    subcommands = ", ".join(_render_add_projection(projection) for projection in operation.projections)
    sql = f"ALTER TABLE {ft} {subcommands}{_settings_suffix(operation.clickhouse_settings)}"
    return _exec_sql(operations, sql)


@Operations.register_operation("drop_clickhouse_projection")
class DropClickHouseProjectionOp(MigrateOperation):
    def __init__(
        self,
        table_name: str,
        name: str,
        *,
        if_exists: bool = False,
        schema: str | None = None,
        clickhouse_settings: Mapping[str, Any] | None = None,
        existing_projection: ClickHouseProjection | None = None,
    ) -> None:
        self.table_name: str = table_name
        self.name: str = name
        self.if_exists: bool = if_exists
        self.schema: str | None = schema
        self.clickhouse_settings: Mapping[str, Any] | None = clickhouse_settings
        self.existing_projection: ClickHouseProjection | None = existing_projection

    def reverse(self) -> MigrateOperation:
        projection = self.existing_projection
        if projection is None:
            return super().reverse()
        return AddClickHouseProjectionOp(
            self.table_name,
            projection.name,
            projection.select,
            schema=self.schema,
            clickhouse_settings=self.clickhouse_settings,
        )

    @classmethod
    def drop_clickhouse_projection(
        cls,
        operations: Operations,
        table_name: str,
        name: str,
        if_exists: bool = False,
        schema: str | None = None,
        clickhouse_settings: Mapping[str, Any] | None = None,
    ) -> Any:
        """Emit ALTER TABLE ... DROP PROJECTION.

        Schedules a mutation governed by alter_sync (recommend 0, 1, or 2), not mutations_sync.
        """
        return operations.invoke(
            cls(
                table_name,
                name,
                if_exists=if_exists,
                schema=schema,
                clickhouse_settings=clickhouse_settings,
            )
        )


@Operations.implementation_for(DropClickHouseProjectionOp)
def _drop_clickhouse_projection(operations: Operations, operation: DropClickHouseProjectionOp) -> Any:
    ft = full_table(operation.table_name, operation.schema)
    exists = "IF EXISTS " if operation.if_exists else ""
    sql = f"ALTER TABLE {ft} DROP PROJECTION {exists}{quote_identifier(operation.name)}{_settings_suffix(operation.clickhouse_settings)}"
    return _exec_sql(operations, sql)


@Operations.register_operation("drop_clickhouse_projections")
class DropClickHouseProjectionsOp(MigrateOperation):
    def __init__(
        self,
        table_name: str,
        names: Sequence[str],
        *,
        if_exists: bool = False,
        schema: str | None = None,
        clickhouse_settings: Mapping[str, Any] | None = None,
    ) -> None:
        self.table_name: str = table_name
        self.names: tuple[str, ...] = tuple(names)
        if not self.names:
            raise ValueError("drop_clickhouse_projections requires at least one projection name")
        self.if_exists: bool = if_exists
        self.schema: str | None = schema
        self.clickhouse_settings: Mapping[str, Any] | None = clickhouse_settings

    @classmethod
    def drop_clickhouse_projections(
        cls,
        operations: Operations,
        table_name: str,
        names: Sequence[str],
        if_exists: bool = False,
        schema: str | None = None,
        clickhouse_settings: Mapping[str, Any] | None = None,
    ) -> Any:
        """Emit ONE comma-joined ALTER TABLE ... DROP PROJECTION, DROP PROJECTION ... statement."""
        return operations.invoke(
            cls(
                table_name,
                names,
                if_exists=if_exists,
                schema=schema,
                clickhouse_settings=clickhouse_settings,
            )
        )


@Operations.implementation_for(DropClickHouseProjectionsOp)
def _drop_clickhouse_projections(operations: Operations, operation: DropClickHouseProjectionsOp) -> Any:
    ft = full_table(operation.table_name, operation.schema)
    exists = "IF EXISTS " if operation.if_exists else ""
    subcommands = ", ".join(f"DROP PROJECTION {exists}{quote_identifier(name)}" for name in operation.names)
    sql = f"ALTER TABLE {ft} {subcommands}{_settings_suffix(operation.clickhouse_settings)}"
    return _exec_sql(operations, sql)


@Operations.register_operation("materialize_clickhouse_projection")
class MaterializeClickHouseProjectionOp(MigrateOperation):
    def __init__(
        self,
        table_name: str,
        name: str,
        *,
        if_exists: bool = False,
        partition: str | None = None,
        schema: str | None = None,
        clickhouse_settings: Mapping[str, Any] | None = None,
    ) -> None:
        self.table_name: str = table_name
        self.name: str = name
        self.if_exists: bool = if_exists
        self.partition: str | None = partition
        self.schema: str | None = schema
        self.clickhouse_settings: Mapping[str, Any] | None = clickhouse_settings

    @classmethod
    def materialize_clickhouse_projection(
        cls,
        operations: Operations,
        table_name: str,
        name: str,
        if_exists: bool = False,
        partition: str | None = None,
        schema: str | None = None,
        clickhouse_settings: Mapping[str, Any] | None = None,
    ) -> Any:
        """Emit ALTER TABLE ... MATERIALIZE PROJECTION to backfill existing parts.

        partition is raw SQL passthrough. Schedules a mutation governed by mutations_sync
        (recommend 0, 1, or 2). Kept as a separate statement by design: Replicated databases
        reject ADD PROJECTION and MATERIALIZE PROJECTION combined in one statement.
        """
        return operations.invoke(
            cls(
                table_name,
                name,
                if_exists=if_exists,
                partition=partition,
                schema=schema,
                clickhouse_settings=clickhouse_settings,
            )
        )


@Operations.implementation_for(MaterializeClickHouseProjectionOp)
def _materialize_clickhouse_projection(operations: Operations, operation: MaterializeClickHouseProjectionOp) -> Any:
    ft = full_table(operation.table_name, operation.schema)
    exists = "IF EXISTS " if operation.if_exists else ""
    partition = f" IN PARTITION {operation.partition}" if operation.partition is not None else ""
    sql = (
        f"ALTER TABLE {ft} MATERIALIZE PROJECTION {exists}{quote_identifier(operation.name)}"
        f"{partition}{_settings_suffix(operation.clickhouse_settings)}"
    )
    return _exec_sql(operations, sql)


@Operations.register_operation("modify_clickhouse_table_settings")
class ModifyClickHouseTableSettingsOp(MigrateOperation):
    def __init__(
        self,
        table_name: str,
        settings: Mapping[str, Any],
        *,
        schema: str | None = None,
        clickhouse_settings: Mapping[str, Any] | None = None,
        existing_settings: Mapping[str, Any] | None = None,
    ) -> None:
        if not settings:
            raise ValueError("modify_clickhouse_table_settings requires at least one setting")
        self.table_name: str = table_name
        self.settings: Mapping[str, Any] = settings
        self.schema: str | None = schema
        self.clickhouse_settings: Mapping[str, Any] | None = clickhouse_settings
        # Previous values for autogenerate downgrades. None means the setting was not set.
        self.existing_settings: Mapping[str, Any] | None = existing_settings

    def reverse(self) -> MigrateOperation:
        if self.existing_settings is None:
            raise NotImplementedError("modify_clickhouse_table_settings needs existing_settings to reverse")
        restore = {name: value for name, value in self.existing_settings.items() if value is not None}
        reset = [name for name, value in self.existing_settings.items() if value is None]
        reversed_ops: list[MigrateOperation] = []
        if restore:
            reversed_ops.append(
                ModifyClickHouseTableSettingsOp(self.table_name, restore, schema=self.schema, clickhouse_settings=self.clickhouse_settings)
            )
        if reset:
            reversed_ops.append(
                ResetClickHouseTableSettingsOp(self.table_name, reset, schema=self.schema, clickhouse_settings=self.clickhouse_settings)
            )
        if len(reversed_ops) == 1:
            return reversed_ops[0]
        return ModifyTableOps(self.table_name, reversed_ops, schema=self.schema)

    def to_diff_tuple(self) -> tuple[Any, ...]:
        return ("modify_clickhouse_table_settings", self.schema, self.table_name, dict(self.settings), self.existing_settings)

    @classmethod
    def modify_clickhouse_table_settings(
        cls,
        operations: Operations,
        table_name: str,
        settings: Mapping[str, Any],
        schema: str | None = None,
        clickhouse_settings: Mapping[str, Any] | None = None,
    ) -> Any:
        """Emit ALTER TABLE ... MODIFY SETTING.

        settings are the table-level settings to change. clickhouse_settings is the separate
        query-level SETTINGS clause. Metadata-only, no mutation to wait on. Raises ValueError
        if settings is empty.
        """
        return operations.invoke(
            cls(
                table_name,
                settings,
                schema=schema,
                clickhouse_settings=clickhouse_settings,
            )
        )


@Operations.implementation_for(ModifyClickHouseTableSettingsOp)
def _modify_clickhouse_table_settings(operations: Operations, operation: ModifyClickHouseTableSettingsOp) -> Any:
    ft = full_table(operation.table_name, operation.schema)
    sql = f"ALTER TABLE {ft} MODIFY SETTING {render_settings(operation.settings)}{_settings_suffix(operation.clickhouse_settings)}"
    return _exec_sql(operations, sql)


@Operations.register_operation("reset_clickhouse_table_settings")
class ResetClickHouseTableSettingsOp(MigrateOperation):
    def __init__(
        self,
        table_name: str,
        names: Sequence[str],
        *,
        schema: str | None = None,
        clickhouse_settings: Mapping[str, Any] | None = None,
    ) -> None:
        if not names:
            raise ValueError("reset_clickhouse_table_settings requires at least one setting name")
        self.table_name: str = table_name
        self.names: tuple[str, ...] = tuple(names)
        self.schema: str | None = schema
        self.clickhouse_settings: Mapping[str, Any] | None = clickhouse_settings

    @classmethod
    def reset_clickhouse_table_settings(
        cls,
        operations: Operations,
        table_name: str,
        names: Sequence[str],
        schema: str | None = None,
        clickhouse_settings: Mapping[str, Any] | None = None,
    ) -> Any:
        """Emit ALTER TABLE ... RESET SETTING.

        names are bare setting names to reset to their defaults. Metadata-only, no mutation
        to wait on. Raises ValueError if names is empty.
        """
        return operations.invoke(
            cls(
                table_name,
                names,
                schema=schema,
                clickhouse_settings=clickhouse_settings,
            )
        )


@Operations.implementation_for(ResetClickHouseTableSettingsOp)
def _reset_clickhouse_table_settings(operations: Operations, operation: ResetClickHouseTableSettingsOp) -> Any:
    ft = full_table(operation.table_name, operation.schema)
    names = ", ".join(operation.names)
    sql = f"ALTER TABLE {ft} RESET SETTING {names}{_settings_suffix(operation.clickhouse_settings)}"
    return _exec_sql(operations, sql)


def _view_identifier(name: str, schema: str | None) -> str:
    # full_table omits the schema for names starting with "(", which are valid view names.
    identifier = quote_identifier(name)
    return f"{quote_identifier(schema)}.{identifier}" if schema else identifier


@Operations.register_operation("create_clickhouse_view")
class CreateClickHouseViewOp(MigrateOperation):
    def __init__(
        self,
        name: str,
        select: str,
        *,
        if_not_exists: bool = False,
        or_replace: bool = False,
        schema: str | None = None,
    ) -> None:
        if if_not_exists and or_replace:
            raise ValueError("if_not_exists and or_replace are mutually exclusive")
        self.name: str = name
        self.select: str = select
        self.if_not_exists: bool = if_not_exists
        self.or_replace: bool = or_replace
        self.schema: str | None = schema

    @classmethod
    def create_clickhouse_view(
        cls,
        operations: Operations,
        name: str,
        select: str,
        if_not_exists: bool = False,
        or_replace: bool = False,
        schema: str | None = None,
    ) -> Any:
        """Create an ordinary view; select is raw SQL.

        or_replace can replace a table or materialized view with the same name,
        discarding its data. Guarded creation and replacement need explicit downgrades.
        """
        return operations.invoke(cls(name, select, if_not_exists=if_not_exists, or_replace=or_replace, schema=schema))

    def reverse(self) -> MigrateOperation:
        if self.or_replace or self.if_not_exists:
            raise NotImplementedError("Guarded or replacement creation requires an explicit downgrade with the previous definition")
        return DropClickHouseViewOp(self.name, if_exists=True, schema=self.schema)


@Operations.implementation_for(CreateClickHouseViewOp)
def _create_clickhouse_view(operations: Operations, operation: CreateClickHouseViewOp) -> None:
    replace = " OR REPLACE" if operation.or_replace else ""
    exists = " IF NOT EXISTS" if operation.if_not_exists else ""
    sql = f"CREATE{replace} VIEW{exists} {_view_identifier(operation.name, operation.schema)} AS {operation.select}"
    _exec_sql(operations, sql, literal_sql=True)


@Operations.register_operation("drop_clickhouse_view")
class DropClickHouseViewOp(MigrateOperation):
    def __init__(self, name: str, *, if_exists: bool = False, schema: str | None = None) -> None:
        self.name: str = name
        self.if_exists: bool = if_exists
        self.schema: str | None = schema

    @classmethod
    def drop_clickhouse_view(cls, operations: Operations, name: str, if_exists: bool = False, schema: str | None = None) -> Any:
        """Drop a view."""
        return operations.invoke(cls(name, if_exists=if_exists, schema=schema))


@Operations.implementation_for(DropClickHouseViewOp)
def _drop_clickhouse_view(operations: Operations, operation: DropClickHouseViewOp) -> None:
    exists = " IF EXISTS" if operation.if_exists else ""
    _exec_sql(operations, f"DROP VIEW{exists} {_view_identifier(operation.name, operation.schema)}", literal_sql=True)


@Operations.register_operation("create_clickhouse_function")
class CreateClickHouseFunctionOp(MigrateOperation):
    def __init__(
        self,
        name: str,
        expression: str,
        *,
        if_not_exists: bool = False,
        or_replace: bool = False,
    ) -> None:
        if if_not_exists and or_replace:
            raise ValueError("if_not_exists and or_replace are mutually exclusive")
        self.name: str = name
        self.expression: str = expression
        self.if_not_exists: bool = if_not_exists
        self.or_replace: bool = or_replace

    @classmethod
    def create_clickhouse_function(
        cls,
        operations: Operations,
        name: str,
        expression: str,
        if_not_exists: bool = False,
        or_replace: bool = False,
    ) -> Any:
        """Create a server-global SQL function; expression is a raw SQL lambda.

        Function names are not database-scoped. Guarded creation and replacement
        need explicit downgrades with the previous definition.
        """
        return operations.invoke(cls(name, expression, if_not_exists=if_not_exists, or_replace=or_replace))

    def reverse(self) -> MigrateOperation:
        if self.or_replace or self.if_not_exists:
            raise NotImplementedError("Guarded or replacement creation requires an explicit downgrade with the previous definition")
        return DropClickHouseFunctionOp(self.name, if_exists=True)


@Operations.implementation_for(CreateClickHouseFunctionOp)
def _create_clickhouse_function(operations: Operations, operation: CreateClickHouseFunctionOp) -> None:
    replace = " OR REPLACE" if operation.or_replace else ""
    exists = " IF NOT EXISTS" if operation.if_not_exists else ""
    sql = f"CREATE{replace} FUNCTION{exists} {quote_identifier(operation.name)} AS {operation.expression}"
    _exec_sql(operations, sql, literal_sql=True)


@Operations.register_operation("drop_clickhouse_function")
class DropClickHouseFunctionOp(MigrateOperation):
    def __init__(self, name: str, *, if_exists: bool = False) -> None:
        self.name: str = name
        self.if_exists: bool = if_exists

    @classmethod
    def drop_clickhouse_function(cls, operations: Operations, name: str, if_exists: bool = False) -> Any:
        """Drop a server-global SQL function."""
        return operations.invoke(cls(name, if_exists=if_exists))


@Operations.implementation_for(DropClickHouseFunctionOp)
def _drop_clickhouse_function(operations: Operations, operation: DropClickHouseFunctionOp) -> None:
    exists = " IF EXISTS" if operation.if_exists else ""
    _exec_sql(operations, f"DROP FUNCTION{exists} {quote_identifier(operation.name)}", literal_sql=True)


@Operations.register_operation("create_clickhouse_materialized_view")
class CreateClickHouseMaterializedViewOp(MigrateOperation):
    def __init__(
        self,
        name: str,
        to_table: str,
        select: str,
        *,
        if_not_exists: bool = False,
        schema: str | None = None,
        to_schema: str | None = None,
    ) -> None:
        self.name: str = name
        self.to_table: str = to_table
        self.select: str = select
        self.if_not_exists: bool = if_not_exists
        self.schema: str | None = schema
        self.to_schema: str | None = to_schema

    @classmethod
    def create_clickhouse_materialized_view(
        cls,
        operations: Operations,
        name: str,
        to_table: str,
        select: str,
        if_not_exists: bool = False,
        schema: str | None = None,
        to_schema: str | None = None,
    ) -> Any:
        """Emit CREATE MATERIALIZED VIEW ... TO ... AS ...

        select is raw SQL passthrough. This helper intentionally supports only the
        TO-table form because ENGINE and POPULATE are not valid with TO. ClickHouse
        treats SETTINGS after AS SELECT as part of the stored SELECT, so this helper
        does not accept clickhouse_settings.
        """
        return operations.invoke(
            cls(
                name,
                to_table,
                select,
                if_not_exists=if_not_exists,
                schema=schema,
                to_schema=to_schema,
            )
        )

    def reverse(self) -> MigrateOperation:
        return DropClickHouseMaterializedViewOp(
            self.name,
            if_exists=True,
            schema=self.schema,
        )


@Operations.implementation_for(CreateClickHouseMaterializedViewOp)
def _create_clickhouse_materialized_view(operations: Operations, operation: CreateClickHouseMaterializedViewOp) -> Any:
    exists = " IF NOT EXISTS" if operation.if_not_exists else ""
    sql = (
        f"CREATE MATERIALIZED VIEW{exists} {full_table(operation.name, operation.schema)} "
        f"TO {full_table(operation.to_table, operation.to_schema)} AS {operation.select}"
    )
    return _exec_sql(operations, sql)


@Operations.register_operation("drop_clickhouse_materialized_view")
class DropClickHouseMaterializedViewOp(MigrateOperation):
    def __init__(
        self,
        name: str,
        *,
        if_exists: bool = False,
        schema: str | None = None,
        clickhouse_settings: Mapping[str, Any] | None = None,
    ) -> None:
        self.name: str = name
        self.if_exists: bool = if_exists
        self.schema: str | None = schema
        self.clickhouse_settings: Mapping[str, Any] | None = clickhouse_settings

    @classmethod
    def drop_clickhouse_materialized_view(
        cls,
        operations: Operations,
        name: str,
        if_exists: bool = False,
        schema: str | None = None,
        clickhouse_settings: Mapping[str, Any] | None = None,
    ) -> Any:
        """Emit DROP VIEW for a ClickHouse materialized view."""
        return operations.invoke(
            cls(
                name,
                if_exists=if_exists,
                schema=schema,
                clickhouse_settings=clickhouse_settings,
            )
        )


@Operations.implementation_for(DropClickHouseMaterializedViewOp)
def _drop_clickhouse_materialized_view(operations: Operations, operation: DropClickHouseMaterializedViewOp) -> Any:
    exists = " IF EXISTS" if operation.if_exists else ""
    sql = f"DROP VIEW{exists} {full_table(operation.name, operation.schema)}{_settings_suffix(operation.clickhouse_settings)}"
    return _exec_sql(operations, sql)


@Operations.register_operation("create_clickhouse_dictionary")
class CreateClickHouseDictionaryOp(MigrateOperation):
    def __init__(
        self,
        name: str,
        columns: Sequence[Column[Any]],
        *,
        primary_key: str,
        source: str,
        layout: str,
        lifetime: str,
        if_not_exists: bool = False,
        schema: str | None = None,
        comment: str | None = None,
        clickhouse_settings: Mapping[str, Any] | None = None,
    ) -> None:
        self.name: str = name
        self.columns: tuple[Column[Any], ...] = tuple(columns)
        if not self.columns:
            raise ValueError("create_clickhouse_dictionary requires at least one column")
        self.primary_key: str = primary_key
        self.source: str = source
        self.layout: str = layout
        self.lifetime: str = lifetime
        self.if_not_exists: bool = if_not_exists
        self.schema: str | None = schema
        self.comment: str | None = comment
        self.clickhouse_settings: Mapping[str, Any] | None = clickhouse_settings

    @classmethod
    def create_clickhouse_dictionary(
        cls,
        operations: Operations,
        name: str,
        columns: Sequence[Column[Any]],
        *,
        primary_key: str,
        source: str,
        layout: str,
        lifetime: str,
        if_not_exists: bool = False,
        schema: str | None = None,
        comment: str | None = None,
        clickhouse_settings: Mapping[str, Any] | None = None,
    ) -> Any:
        """Emit CREATE DICTIONARY.

        source, layout, lifetime, and primary_key are raw ClickHouse SQL fragments.
        Columns are SQLAlchemy Column objects rendered through the ClickHouse DDL compiler.
        """
        return operations.invoke(
            cls(
                name,
                columns,
                primary_key=primary_key,
                source=source,
                layout=layout,
                lifetime=lifetime,
                if_not_exists=if_not_exists,
                schema=schema,
                comment=comment,
                clickhouse_settings=clickhouse_settings,
            )
        )

    def reverse(self) -> MigrateOperation:
        return DropClickHouseDictionaryOp(
            self.name,
            if_exists=True,
            schema=self.schema,
            clickhouse_settings=self.clickhouse_settings,
        )


@Operations.implementation_for(CreateClickHouseDictionaryOp)
def _create_clickhouse_dictionary(operations: Operations, operation: CreateClickHouseDictionaryOp) -> Any:
    exists = " IF NOT EXISTS" if operation.if_not_exists else ""
    layout = operation.layout if "(" in operation.layout else f"{operation.layout}()"
    sql = (
        f"CREATE DICTIONARY{exists} {full_table(operation.name, operation.schema)} "
        f"({_render_column_list(operations, operation.columns)}) "
        f"PRIMARY KEY {operation.primary_key} SOURCE({operation.source}) "
        f"LAYOUT({layout}) LIFETIME({operation.lifetime})"
    )
    settings = _settings_suffix(operation.clickhouse_settings)
    if operation.comment is not None:
        sql += f" COMMENT {format_str(operation.comment)}"
    elif settings:
        # ClickHouse parses bare SETTINGS after LIFETIME as dictionary settings.
        # COMMENT ends the dictionary body so the trailing SETTINGS is query-level.
        sql += " COMMENT ''"
    sql += settings
    return _exec_sql(operations, sql)


@Operations.register_operation("drop_clickhouse_dictionary")
class DropClickHouseDictionaryOp(MigrateOperation):
    def __init__(
        self,
        name: str,
        *,
        if_exists: bool = False,
        schema: str | None = None,
        clickhouse_settings: Mapping[str, Any] | None = None,
    ) -> None:
        self.name: str = name
        self.if_exists: bool = if_exists
        self.schema: str | None = schema
        self.clickhouse_settings: Mapping[str, Any] | None = clickhouse_settings

    @classmethod
    def drop_clickhouse_dictionary(
        cls,
        operations: Operations,
        name: str,
        if_exists: bool = False,
        schema: str | None = None,
        clickhouse_settings: Mapping[str, Any] | None = None,
    ) -> Any:
        """Emit DROP DICTIONARY."""
        return operations.invoke(
            cls(
                name,
                if_exists=if_exists,
                schema=schema,
                clickhouse_settings=clickhouse_settings,
            )
        )


@Operations.implementation_for(DropClickHouseDictionaryOp)
def _drop_clickhouse_dictionary(operations: Operations, operation: DropClickHouseDictionaryOp) -> Any:
    exists = " IF EXISTS" if operation.if_exists else ""
    sql = f"DROP DICTIONARY{exists} {full_table(operation.name, operation.schema)}{_settings_suffix(operation.clickhouse_settings)}"
    return _exec_sql(operations, sql)


@Operations.register_operation("reload_clickhouse_dictionary")
class ReloadClickHouseDictionaryOp(MigrateOperation):
    def __init__(self, name: str, *, schema: str | None = None) -> None:
        self.name: str = name
        self.schema: str | None = schema

    @classmethod
    def reload_clickhouse_dictionary(
        cls,
        operations: Operations,
        name: str,
        schema: str | None = None,
    ) -> Any:
        """Emit SYSTEM RELOAD DICTIONARY.

        Synchronous and blocking. Runs only on the node that receives it, not through the
        replicated DDL queue.
        """
        return operations.invoke(cls(name, schema=schema))


@Operations.implementation_for(ReloadClickHouseDictionaryOp)
def _reload_clickhouse_dictionary(operations: Operations, operation: ReloadClickHouseDictionaryOp) -> Any:
    sql = f"SYSTEM RELOAD DICTIONARY {full_table(operation.name, operation.schema)}"
    return _exec_sql(operations, sql)


# Compatibility aliases preserve existing imports.
_AddClickHouseIndexOp = AddClickHouseIndexOp
_AddClickHouseIndexesOp = AddClickHouseIndexesOp
_DropClickHouseIndexOp = DropClickHouseIndexOp
_DropClickHouseIndexesOp = DropClickHouseIndexesOp
_MaterializeClickHouseIndexOp = MaterializeClickHouseIndexOp
_AddClickHouseProjectionOp = AddClickHouseProjectionOp
_AddClickHouseProjectionsOp = AddClickHouseProjectionsOp
_DropClickHouseProjectionOp = DropClickHouseProjectionOp
_DropClickHouseProjectionsOp = DropClickHouseProjectionsOp
_MaterializeClickHouseProjectionOp = MaterializeClickHouseProjectionOp
_ModifyClickHouseTableSettingsOp = ModifyClickHouseTableSettingsOp
_ResetClickHouseTableSettingsOp = ResetClickHouseTableSettingsOp
_CreateClickHouseViewOp = CreateClickHouseViewOp
_DropClickHouseViewOp = DropClickHouseViewOp
_CreateClickHouseFunctionOp = CreateClickHouseFunctionOp
_DropClickHouseFunctionOp = DropClickHouseFunctionOp
_CreateClickHouseMaterializedViewOp = CreateClickHouseMaterializedViewOp
_DropClickHouseMaterializedViewOp = DropClickHouseMaterializedViewOp
_CreateClickHouseDictionaryOp = CreateClickHouseDictionaryOp
_DropClickHouseDictionaryOp = DropClickHouseDictionaryOp
_ReloadClickHouseDictionaryOp = ReloadClickHouseDictionaryOp
